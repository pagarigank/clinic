# Multi-Tenant Clinic Platform — Functional Specification

**Version:** 1.0 (draft) · **Date:** 2026-09-30
**Companion docs:** [architecture.md](architecture.md) · [frontend.md](frontend.md) · [todo.md](todo.md)

This document defines **what** the system does: roles, data, every CRUD, every transactional workflow, every report, and every background job.

## Contents

1. Conventions & legend
2. Roles & permissions
3. Global business rules
4. M1 Platform Console (Superadmin)
5. M2 Tenant Administration
6. M3 Patients
7. M4 Clinical (scheduling, visits, orders)
8. M5 Laboratory
9. M6 Pharmacy
10. M7 Central Supply
11. M8 Billing & Cashiering
12. M9 Compliance & Audit
13. M10 Notifications
14. Background job catalog (JOB-01…JOB-50)
15. Report catalog (RPT-*)
16. Non-functional requirements
17. Acceptance scenarios

---

## 1. Conventions & Legend

- **Priority:** `P0` = MVP/go-live blocker · `P1` = needed for GA · `P2` = later.
- **CRUD legend:** `C` create · `R` read/list/search · `U` update · `D` delete. Because this is a clinical/financial system, **D never means hard delete** unless stated: `Archive` (soft-delete, `deleted_at`), `Void` (posted document reversed with reason), `Deactivate` (users), or `—` (not allowed).
- **Standard columns** on every tenant table: `id`, `tenant_id`, `created_at/by`, `updated_at/by`, `row_version`; archivable masters add `deleted_at`; branch-scoped tables add `branch_id`. These are not repeated below.
- **Permission naming:** `module.resource.action` (e.g., `lab.result.verify`).
- **Document numbers:** generated per tenant/branch/period from `number_sequences` (e.g., `PO-2026-000123`).
- **Every list endpoint** supports search, filter, sort, pagination; every screen has a matching CSV/XLSX export where noted in §15.

---

## 2. Roles & Permissions

### 2.1 Actors

| Role (system template) | Scope | Who |
|---|---|---|
| `SUPERADMIN` | Platform | Platform owner; creates tenants & tenant admins; can enter any clinic (audited) |
| `PLATFORM_SUPPORT` *(optional)* | Platform | Read-only tenant metadata; no PHI |
| `TENANT_ADMIN` | Tenant | Administers the company: branches, users, roles, settings, master data |
| `BRANCH_MANAGER` | Branch(es) | Operational oversight, approvals, reports |
| `DOCTOR` | Branch(es) | Physician/practitioner: consults, prescribes, orders, signs |
| `NURSE` | Branch(es) | Triage, vitals, procedures, in-clinic administration, supply usage |
| `ENCODER` | Branch(es) | Front desk: registration, appointments, queue, encoding orders/results (non-verifying) |
| `CASHIER` | Branch(es) | Invoices, payments, shifts |
| `PHARMACIST` | Branch(es) | Verify, dispense (incl. controlled), pharmacy stock |
| `PHARMACY_ASSISTANT` | Branch(es) | Prepare orders, OTC sales (non-controlled), stock counts |
| `PHLEBOTOMIST` | Branch(es) | Specimen collection |
| `MEDTECH` | Branch(es) | Receive specimens, run tests, enter results |
| `LAB_MANAGER` | Branch(es) | Lab config, QC, verify, amend, reagent stock |
| `PATHOLOGIST` | Branch(es) | Final verification/sign-off, interpretive comments |
| `SUPPLY_OFFICER` | Branch(es) | Central store custodian: receiving, issuing, counts, disposal |
| `PURCHASER` | Tenant/Branch | PR/PO, suppliers |
| `AUDITOR` | Tenant | Read-only incl. audit logs (no PHI content unless granted) |
| `DPO` | Tenant | Privacy: consents, DSRs, breach register, access logs |

Tenant admins may clone/modify roles (permission sets) per tenant; system templates are re-seeded only for new tenants.

### 2.2 Module access matrix (default template)

`F` full CRUD+transitions · `R` read · `C/R/U` no delete · `A` approvals · `—` none

| Role | Platform | Tenant Admin | Patients | Clinical | Lab | Pharmacy | Supply | Billing | Compliance | Reports |
|---|---|---|---|---|---|---|---|---|---|---|
| SUPERADMIN | F | F (via enter-clinic) | via enter-clinic | via enter-clinic | via enter-clinic | via enter-clinic | via enter-clinic | via enter-clinic | R | Platform + clinic |
| TENANT_ADMIN | — | F | C/R/U | R | R | R | R | R | R | All (tenant) |
| BRANCH_MANAGER | — | R (own branch) | C/R/U | R, A | R, A | R, A | R, A | R, A | R | Branch |
| DOCTOR | — | — | R, U(clinical) | F (own) | order, view | prescribe | — | — | — | Clinical |
| NURSE | — | — | R | C/R/U | collect | R | requisition, consumption | — | — | Clinical |
| ENCODER | — | — | C/R/U | appointments, queue | order, encode results (no verify) | — | — | charge capture | — | Basic |
| CASHIER | — | — | R (demographics) | — | — | — | — | F | — | Billing |
| PHARMACIST | — | — | R | R | — | F (+controlled) | requisition, receive | sales | — | Pharmacy |
| PHARMACY_ASSISTANT | — | — | R | R (Rx) | — | prepare, OTC | counts | — | — | — |
| PHLEBOTOMIST | — | — | R | R | collect | — | — | — | — | — |
| MEDTECH | — | — | R | R | C/R/U results | — | reagent requisition | — | — | Lab |
| LAB_MANAGER | — | — | R | R | F (+verify, QC) | — | R, requisition | — | — | Lab |
| PATHOLOGIST | — | — | R | R | verify, amend | — | — | — | — | Lab |
| SUPPLY_OFFICER | — | — | — | — | — | — | F | — | — | Supply |
| PURCHASER | — | — | — | — | — | — | PR/PO/suppliers | — | — | Supply |
| AUDITOR | — | R | — | — | — | — | — | — | R (audit) | All (no PHI) |
| DPO | — | R | R (access log) | — | — | — | — | — | F | Compliance |

Permission catalog (non-exhaustive, seeded): `platform.tenant.*`, `admin.user.*`, `admin.role.*`, `patient.record.{create,read,update,merge,restricted_read}`, `clinical.visit.*`, `clinical.note.{sign,amend}`, `clinical.rx.{create,sign}`, `lab.order.*`, `lab.specimen.*`, `lab.result.{enter,verify,amend,view_confidential}`, `lab.qc.*`, `pharmacy.rx.{verify,dispense}`, `pharmacy.controlled.{dispense,witness,report}`, `pharmacy.sale.*`, `supply.item.*`, `supply.po.{create,approve}`, `supply.grn.post`, `supply.requisition.{create,approve,issue,receive}`, `supply.adjust.{create,approve}`, `supply.count.*`, `supply.dispose.*`, `supply.recall.*`, `billing.invoice.*`, `billing.payment.*`, `billing.void`, `compliance.*`, `reports.*.view|export`.

---

## 3. Global Business Rules

| ID | Rule |
|---|---|
| G-01 | **Tenant isolation:** no user or job can read/write another tenant's data (enforced by RLS + app layers). Superadmin access to clinic data only via audited *enter-clinic*. |
| G-02 | Users belong to exactly one tenant; access to branches by assignment. Branch-scoped records are visible only to users assigned to that branch (tenant admins see all branches). |
| G-03 | Posted documents (GRN, issue, dispense, invoice, payment, adjustment, verified lab result, signed note) are **immutable**; corrections use void/reversal/amendment with reason, actor and timestamp. |
| G-04 | Stock never goes negative; every stock change is a ledger movement linked to a source document. |
| G-05 | Expired, quarantined, recalled batches cannot be issued, dispensed, or consumed. |
| G-06 | Optimistic concurrency via `row_version`; conflicting edits return HTTP 412. |
| G-07 | All writes and all PHI reads are audited (audit_log / phi_access_log). |
| G-08 | Time stored in UTC; rendered in tenant timezone (default `Asia/Manila`); schedules evaluated in tenant timezone. |
| G-09 | Currency PHP (tenant-configurable); quantities in base UOM; decimals configurable per item. |
| G-10 | Dangerous/controlled drugs: no refills; special-prescription data captured; register entry on every movement; witness required on dispense/disposal/waste. Legal periods/forms are configuration. |
| G-11 | Segregation of duties configurable (entry≠verify, PO create≠approve, adjustment request≠approve). |
| G-12 | Soft-deleted masters remain referenced by historical records and are hidden from pickers. |
| G-13 | Patient data changes keep history (versioned demographics); merges are logged and reversible within a window. |
| G-14 | Every approval/verification/void/refund/controlled action requires step-up authentication. |
| G-15 | Suspended tenants: read-only for admins (export allowed); clinical users blocked; jobs paused except export/retention. |

---

## 4. M1 — Platform Console (Superadmin)

### 4.1 Entities

| Table | Key columns |
|---|---|
| `platform_users` | email, name, password_hash, mfa_secret, role (`SUPERADMIN`/`PLATFORM_SUPPORT`), status, last_login_at |
| `tenants` | name, legal_name, slug (unique), status (`PROVISIONING/ACTIVE/SUSPENDED/OFFBOARDING/PURGED`), timezone, locale, country, plan_id, branding (logo_file_id, primary_color), dpo_name/email, data_region/db_shard, trial_ends_at, suspended_reason |
| `tenant_directory` | id, slug, status, db_shard (no RLS; non-PHI) |
| `subscription_plans` | code, name, price, limits (branches, users, storage_gb, patients), features (JSON), status |
| `tenant_subscriptions` | tenant_id, plan_id, period_start/end, status, auto_renew |
| `tenant_feature_flags` | tenant_id, flag, enabled, config |
| `breakglass_sessions` | platform_user_id, tenant_id, reason, started_at, expires_at, ended_at, actions_count |
| `platform_announcements` | title, body, audience, starts_at, ends_at |
| `system_settings` | key, value (global defaults: password policy, retention defaults) |
| Global reference (no `tenant_id`, read-only to tenants) | `icd10_codes`, `psgc_locations`, `uom_templates`, `drug_schedule_templates`, `role_templates`, `permissions`, `lab_test_templates`, `loinc_subset` |

### 4.2 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Tenant | ✔ wizard | ✔ | ✔ profile/plan/limits/flags | Suspend / Reactivate / Offboard | No hard delete; `PURGED` by JOB-05 only |
| Tenant admin (tenant user with `TENANT_ADMIN`) | ✔ invite (initial + additional) | ✔ across tenants | ✔ reset password, reset MFA, change email | Deactivate | Email invite with one-time activation link |
| Tenant users (any role) | — (tenant admin does) | ✔ directory across tenants | ✔ unlock/reset | Deactivate | Superadmin sees “all individual admins, encoders, and others” |
| Branches (all tenants) | — | ✔ | — | — | Read across tenants; edits via enter-clinic |
| Platform user | ✔ | ✔ | ✔ | Deactivate | MFA mandatory |
| Subscription plan | ✔ | ✔ | ✔ | Retire | Plans in use cannot be removed |
| Feature flags | ✔ | ✔ | ✔ | ✔ (reset to default) | Per tenant |
| Announcements | ✔ | ✔ | ✔ | Archive | Shown in tenant app |
| Break-glass session | ✔ (enter clinic) | ✔ | End / extend | — | Reason required; immutable once ended |
| System settings | ✔ | ✔ | ✔ | — | Audited |

### 4.3 Transactional workflows

**PLT-T1 Provision tenant** (`POST /platform/tenants`) — saga, idempotent (JOB-03):
1. Validate slug (`[a-z0-9-]{3,40}`, reserved list), plan, timezone, first admin email.
2. Insert `tenants` (`PROVISIONING`) + `tenant_directory`.
3. Seed: roles & permissions from templates; default branch; stock locations (central store, pharmacy, lab, quarantine, waste, in-transit); number sequences; UOM templates; discount types (senior/PWD/promo); lab starter catalog; document templates; consent template v1; retention defaults.
4. Create first `TENANT_ADMIN` (status `INVITED`), send activation email.
5. Set status `ACTIVE`; audit + outbox event. Failure ⇒ compensate (mark `PROVISIONING_FAILED`, retryable).

**PLT-T2 Suspend / reactivate** — reason required; sessions revoked; jobs paused; banner/notice to tenant admins.
**PLT-T3 Change plan** — validates limits (users/branches) before downgrade; effective date; audit.
**PLT-T4 Offboard** — export (JOB-04) → `OFFBOARDING` read-only retention hold (configurable days) → purge (JOB-05) with signed confirmation.
**PLT-T5 Enter clinic (break-glass)** — pick tenant → reason (min 15 chars) → step-up MFA → session created (default 60 min) → tenant-scoped token with `acting_as_platform` → red banner → all actions audited → end/expiry auto-revokes token. Tenant admins notified (default on).
**PLT-T6 Create/reset tenant admin** — invite, resend, revoke invite, force reset, reset MFA (logged + notifies tenant DPO).

### 4.4 Rules
- Only `SUPERADMIN` may create tenants/tenant admins; `PLATFORM_SUPPORT` cannot enter a clinic.
- Break-glass cannot be used to read another tenant concurrently (one active session per platform user).
- Limits from plan enforced at user/branch/storage creation with clear error codes.

---

## 5. M2 — Tenant Administration

### 5.1 Entities

| Table | Key columns |
|---|---|
| `branches` | code, name, address (PSGC), phone, email, timezone override, operating_hours, license_no (DOH LTO), status |
| `users` | email, username, name, phone, password_hash, mfa_secret, status (`INVITED/ACTIVE/LOCKED/DEACTIVATED`), last_login_at, password_changed_at, locale |
| `user_branch_assignments` | user_id, branch_id, is_default |
| `roles` | name, description, is_system, template_code |
| `role_permissions` | role_id, permission_code |
| `user_roles` | user_id, role_id, branch_id (nullable = tenant-wide) |
| `practitioner_profiles` | user_id, prc_license_no, license_expiry, specialty, s2_license_no, s2_expiry, ptr_no, signature_file_id, title/suffix |
| `service_units` (rooms/stations) | branch_id, name, type (consult, procedure, triage, lab, pharmacy) |
| `tenant_settings` | key/value (password policy, MFA policy, SoD flags, shelf-life rule, approval thresholds, critical-value policy, break-glass notify, retention) |
| `number_sequences` | branch_id, doc_type, period, prefix, last_value |
| `document_templates` | type (letterhead, lab_report, rx, certificate, receipt), body/layout, version |
| `discount_types` | code, name, pct/amount, requires_id, legal_basis |
| `payment_methods` | code, name, type (cash, card, e-wallet, bank) |
| `service_catalog` | code, name, category (consult, procedure, lab, other), default_price, is_active |
| `price_lists` / `price_list_items` | name, effective_from/to; item/service price |
| `holidays` / `operating_hours` | date/label; weekday hours |
| `notification_templates` | event, channel, locale, subject, body |
| `api_keys` | name, hash, scopes, last_used_at, expires_at |
| `files` | storage_key, mime, size, sha256, owner_type/id, scan_status |

### 5.2 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Branch | ✔ | ✔ | ✔ | Archive (no active stock/users) | Creating a branch seeds its stock locations |
| User | ✔ invite | ✔ | ✔ profile/roles/branches | Deactivate (revokes sessions) | Email unique per tenant |
| Role | ✔ (clone) | ✔ | ✔ permissions | Archive (unassigned only) | System roles protected from delete |
| Practitioner profile | ✔ | ✔ | ✔ | — | License-expiry reminders (JOB-13) |
| Service unit | ✔ | ✔ | ✔ | Archive | |
| Tenant settings | — | ✔ | ✔ | — | Audited, versioned |
| Document templates | ✔ | ✔ | ✔ (versioned) | Archive | |
| Discount types | ✔ | ✔ | ✔ | Archive | |
| Payment methods | ✔ | ✔ | ✔ | Archive | |
| Service catalog & price lists | ✔ | ✔ | ✔ | Archive | Price changes effective-dated |
| Holidays / hours | ✔ | ✔ | ✔ | ✔ | |
| Notification templates | ✔ | ✔ | ✔ | Archive | |
| API keys | ✔ (shown once) | ✔ (masked) | Rotate | Revoke | |
| Files | ✔ | ✔ | — | Archive | |

### 5.3 Transactional workflows
- **ADM-T1 Invite user:** create (`INVITED`) → email link (24–72 h) → set password + MFA → `ACTIVE`.
- **ADM-T2 Password reset / MFA reset:** self-service via email; admin-initiated with audit.
- **ADM-T3 Role/branch reassignment:** takes effect on next token refresh; active sessions can be force-revoked.
- **ADM-T4 Deactivate user:** revoke sessions/API keys, reassign open tasks (open POs, requisitions, pending verifications).
- **ADM-T5 User access recertification:** quarterly campaign (DPO/Admin reviews each user's roles; attest/revoke).
- **ADM-T6 Settings change:** validated, versioned, audited; critical settings (SoD, critical-value policy) require step-up.

---

## 6. M3 — Patients

### 6.1 Entities

| Table | Key columns |
|---|---|
| `patients` | patient_no (per tenant), last_name, first_name, middle_name, suffix, sex, birth_date, civil_status, nationality, religion, occupation, mobile, email, address (PSGC region/province/city/barangay, street), philhealth_no, senior_id, pwd_id, blood_type, photo_file_id, status (`ACTIVE/INACTIVE/DECEASED/MERGED`), restricted (bool), restricted_reason, merged_into_id |
| `patient_identifiers` | type (national ID, passport, employee no.), value (encrypted), issuer |
| `patient_contacts` | relationship, name, phone, is_guardian, is_emergency |
| `patient_consents` | template_version, purposes[], signed_at, signature_file_id, witness, channel, withdrawn_at |
| `patient_allergies` | substance, drug_class, reaction, severity, status, verified_by |
| `patient_documents` | file_id, category, title, uploaded_by |
| `patient_merge_log` | source_id, target_id, merged_by, reason, snapshot (JSON), unmerged_at |
| `patient_flags` | type (VIP, staff, fall-risk, infectious), note |

### 6.2 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Patient | ✔ (dup-check) | ✔ search (name, DOB, mobile, patient_no, barcode) | ✔ (versioned) | Deactivate / mark deceased | No hard delete; erasure via DSR anonymization (§12) |
| Identifiers | ✔ | ✔ masked | ✔ | Archive | Encrypted at rest |
| Contacts | ✔ | ✔ | ✔ | ✔ | |
| Consents | ✔ | ✔ | — (new version) | Withdraw | |
| Allergies | ✔ | ✔ | ✔ | Mark inactive | Drives Rx/dispense alerts |
| Documents | ✔ | ✔ | ✔ metadata | Archive | Access logged |
| Flags | ✔ | ✔ | ✔ | ✔ | |

### 6.3 Transactional workflows
- **PAT-T1 Register patient (P0):** capture demographics → **duplicate check** (trigram on name + DOB + mobile) shows candidates → consent capture (must exist before clinical data entry) → assign patient_no + printable ID card/QR → audit.
- **PAT-T2 Merge duplicates (P1):** select survivor/source → preview conflicts → merge moves visits/orders/invoices to survivor → source `MERGED` → snapshot stored → **unmerge allowed within 30 days** if no new activity on merged record.
- **PAT-T3 Restricted-record access (P1):** restricted patients require permission + reason per access; logged to `phi_access_log`.
- **PAT-T4 Consent renewal:** when template version changes or purpose added, prompt at next visit.
- **PAT-T5 Data subject request** — see §12.

---

## 7. M4 — Clinical

### 7.1 Entities

| Table | Key columns |
|---|---|
| `practitioner_schedules` | practitioner_id, branch_id, weekday, start/end, slot_minutes, valid_from/to; exceptions (leave) |
| `appointments` | patient_id, practitioner_id, branch_id, service_id, starts_at, ends_at, status (`BOOKED/CONFIRMED/CHECKED_IN/IN_CONSULT/COMPLETED/CANCELLED/NO_SHOW`), channel, notes, reminder_sent_at |
| `queue_tickets` | branch_id, ticket_no, patient_id, priority, service_unit_id, status (`WAITING/CALLED/SERVING/DONE/SKIPPED`), called_at |
| `visits` | visit_no, patient_id, branch_id, appointment_id, type (`OPD/WALK_IN/FOLLOW_UP/PROCEDURE`), status (`OPEN/IN_PROGRESS/READY_FOR_BILLING/CLOSED/CANCELLED`), chief_complaint, practitioner_id, opened_at, closed_at |
| `vitals` | visit_id, recorded_at, bp_sys/dia, hr, rr, temp, spo2, weight, height, bmi (calc), pain_score, recorded_by |
| `clinical_notes` | visit_id, type (SOAP/progress/procedure), subjective, objective, assessment, plan, status (`DRAFT/SIGNED/AMENDED`), signed_by/at, version, amends_id |
| `visit_diagnoses` | visit_id, icd10_code, type (primary/secondary), certainty |
| `problem_list` | patient_id, icd10_code, onset, status |
| `visit_procedures` | visit_id, service_id, performed_by, notes, performed_at |
| `immunizations` | patient_id, vaccine, dose_no, lot (→ stock batch if from stock), site, given_at, given_by |
| `prescriptions` | rx_no, visit_id, patient_id, prescriber_id, status (`DRAFT/ISSUED/PARTIALLY_DISPENSED/DISPENSED/EXPIRED/CANCELLED`), valid_until, is_controlled, special_rx_no, notes |
| `prescription_items` | rx_id, drug_product_id, generic_name, strength, form, route, sig (dose, frequency, duration), qty_prescribed, dispense_as_written, qty_dispensed |
| `lab_orders` | see §8 (created from visit) |
| `medical_certificates` | visit_id, type (fit-to-work, sick leave, clearance), findings, from/to dates, issued_by, doc_no, file_id |
| `referrals` | visit_id, to_facility/practitioner, reason, urgency, status, file_id |
| `visit_supply_usage` | visit_id, item_id, batch_id (auto via FEFO), qty, location_id, posted_movement_id |
| `order_sets` | name, items (lab tests, drugs, services) — templates |
| `clinical_templates` | note templates/macros (per practitioner/tenant) |

### 7.2 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Schedules & exceptions | ✔ | ✔ | ✔ | ✔ | Overlap validation |
| Appointment | ✔ | ✔ | ✔ reschedule | Cancel (reason) | Double-booking prevented by exclusion constraint |
| Queue ticket | ✔ | ✔ | ✔ status | — | |
| Visit | ✔ | ✔ | ✔ while open | Cancel (reason) | Closed visits immutable |
| Vitals | ✔ | ✔ | ✔ (correction logged) | Void | |
| Clinical note | ✔ | ✔ | ✔ while DRAFT | — (amend via addendum) | Signing locks |
| Diagnoses / problems | ✔ | ✔ | ✔ | Remove (draft) / Resolve | ICD-10 picker |
| Procedures | ✔ | ✔ | ✔ | Void | Posts charge |
| Immunizations | ✔ | ✔ | ✔ | Void | |
| Prescription | ✔ | ✔ | ✔ while DRAFT | Cancel (reason) | Issued Rx immutable |
| Medical certificate | ✔ | ✔ | ✔ while draft | Void (reason) | Numbered; PDF with signature |
| Referral | ✔ | ✔ | ✔ | Cancel | |
| Visit supply usage | ✔ | ✔ | ✔ while visit open | Void (reverses movement) | |
| Order sets / templates | ✔ | ✔ | ✔ | Archive | |

### 7.3 Transactional workflows
- **CLN-T1 Book / reschedule / cancel appointment (P0):** availability from schedules − existing − leave/holidays; reminders (JOB-23); no-show auto-mark (JOB-24); cancel policy window configurable.
- **CLN-T2 Check-in & queue (P0):** check-in creates visit (`OPEN`) and queue ticket; call/skip/recall; display-board view.
- **CLN-T3 Triage (P0):** nurse records vitals → abnormal flags (age-specific rules) → priority escalation.
- **CLN-T4 Consultation (P0):** note (SOAP) → diagnoses (ICD-10) → orders (lab, Rx, procedures, supplies, certificate, referral) → **Sign**. Signing locks the note; later changes by **addendum** only.
- **CLN-T5 Prescribe (P0):** choose drug (formulary, stock-aware), sig builder, auto checks (allergy, duplicate therapy, interaction, max dose) with override reasons; controlled drug ⇒ special-Rx fields required (quantity in words and figures, **“no refill”** enforced); **Issue** → appears in pharmacy queue; printable/QR.
- **CLN-T6 Order lab (P0):** select tests/panels → priority (routine/STAT) → clinical info → submit → lab queue; charge captured.
- **CLN-T7 Record supplies used (P1):** nurse scans item → FEFO batch consumed from the clinic-room location (`CONSUMPTION` movement) → charge if billable.
- **CLN-T8 Issue certificate / referral (P1).**
- **CLN-T9 Close visit:** validates all orders have charges/outcomes; status `READY_FOR_BILLING` → `CLOSED` after payment or authorized credit. Stale visits auto-closed by JOB-25 with flag.
- **CLN-T10 Prescription expiry:** Issued Rx expire after `valid_until` (JOB-26).

---

## 8. M5 — Laboratory

### 8.1 Configuration entities

| Table | Key columns |
|---|---|
| `lab_sections` | name (hematology, chemistry, urinalysis, microbiology, serology…), branch_id |
| `specimen_types` | code, name (blood-serum, EDTA blood, urine, stool, swab), container_type, volume_ml, handling, stability_hours |
| `lab_tests` | code, name, section_id, loinc_code, specimen_type_id, method, tat_routine_min, tat_stat_min, price_service_id, is_panel, is_confidential, requires_fasting, instructions, is_active |
| `lab_panel_items` | panel_id, test_id, sort |
| `lab_analytes` | test_id, code, name, unit, result_type (`NUMERIC/TEXT/CODED/CALCULATED`), decimals, formula, coded_values, loinc_code, sort |
| `lab_reference_ranges` | analyte_id, sex, age_min_days, age_max_days, low, high, critical_low, critical_high, text_range, effective_from |
| `lab_delta_rules` | analyte_id, window_days, max_abs_change, max_pct_change |
| `lab_test_reagents` (BOM) | test_id, item_id, qty_per_test (base UOM) |
| `lab_instruments` | name, model, section_id, serial_no, interface_type (manual/HL7/ASTM), calibration_due |
| `lab_qc_materials` / `lab_qc_lots` | analyte, level, lot no., expiry, target_mean, sd |
| `lab_report_templates` | layout per section/test |
| `lab_interface_mappings` | instrument_code ↔ analyte/test code |

### 8.2 Transactional entities

| Table | Key columns |
|---|---|
| `lab_orders` | order_no, patient_id, visit_id, ordered_by, priority, clinical_info, status, ordered_at, source (visit/walk-in/send-in) |
| `lab_order_items` | order_id, test_id, status (`ORDERED/COLLECTED/RECEIVED/IN_PROGRESS/RESULTED/VERIFIED/RELEASED/CANCELLED/REJECTED`), charge_line_id, reagents_consumed_at |
| `specimens` | accession_no (barcode), order_id, specimen_type_id, collected_by/at, received_by/at, condition (ok/hemolyzed/insufficient/clotted/mislabeled), rejected_reason, storage_location |
| `specimen_events` | specimen_id, event (collected, received, aliquoted, stored, discarded, rejected), by, at, note — chain of custody |
| `lab_results` | order_item_id, analyte_id, value_num/text/coded, unit, flag (`N/L/H/LL/HH/A`), ref_range_text, delta_flag, status (`ENTERED/VERIFIED/AMENDED`), entered_by/at, verified_by/at, instrument_id, version |
| `lab_result_amendments` | result_id, old_value, new_value, reason, amended_by, notified_to, at |
| `lab_critical_notifications` | result_id, detected_at, notified_to (person/role), notified_by, method, read_back_confirmed, acknowledged_at, escalated_at |
| `lab_reports` | order_id, version, file_id, sha256, issued_at, issued_by, status (`PRELIMINARY/FINAL/CORRECTED`) |
| `lab_qc_runs` / `lab_qc_results` | instrument, analyte, level, value, z-score, rule_violations (Westgard), status (accept/reject), run_by/at, corrective_action |
| `lab_send_outs` | order_item_id, reference_lab, sent_at, tracking, result_received_at |

### 8.3 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Lab sections, specimen types | ✔ | ✔ | ✔ | Archive | |
| Test / panel / analytes / ranges / delta rules | ✔ | ✔ | ✔ (effective-dated ranges) | Archive | Changing ranges never alters verified results |
| Test↔reagent BOM | ✔ | ✔ | ✔ | ✔ | |
| Instruments, interface mappings | ✔ | ✔ | ✔ | Archive | |
| QC materials/lots | ✔ | ✔ | ✔ | Archive | |
| Lab order | ✔ | ✔ | ✔ while `ORDERED` | Cancel (reason) | Walk-in orders allowed (encoder) |
| Specimen | ✔ collect | ✔ | ✔ condition | Reject (reason) | Barcode label print |
| Results | ✔ enter | ✔ | ✔ before verify | — (amend after verify) | Confidential tests masked |
| Amendments | ✔ | ✔ | — | — | Immutable |
| Critical notifications | ✔ auto | ✔ | ✔ acknowledge | — | |
| Reports | ✔ generate | ✔ | — | — | Versioned; corrected reports retain history |
| QC runs | ✔ | ✔ | ✔ corrective action | Void | |
| Send-outs | ✔ | ✔ | ✔ | Cancel | |

### 8.4 Order → Result lifecycle

```mermaid
stateDiagram-v2
  [*] --> ORDERED
  ORDERED --> COLLECTED: collect specimen
  ORDERED --> CANCELLED: cancel (reason)
  COLLECTED --> RECEIVED: lab accession
  COLLECTED --> REJECTED: reject (reason)
  REJECTED --> ORDERED: recollect
  RECEIVED --> IN_PROGRESS: start run
  IN_PROGRESS --> RESULTED: results entered/imported
  RESULTED --> VERIFIED: verify (2nd person / pathologist)
  RESULTED --> IN_PROGRESS: repeat / reflex
  VERIFIED --> RELEASED: release report
  RELEASED --> RELEASED: corrected report (amendment, version+1)
```

### 8.5 Transactional workflows & rules
- **LAB-T1 Place order (P0):** from visit or walk-in; panel expands to tests; STAT flagged; fasting/instructions shown; charge posted (configurable at order or at collection).
- **LAB-T2 Collect specimen (P0):** scan patient ID → print labels (accession barcode, patient, test, tube) → record collector/time/site → partial collection allowed. Mislabel protection: two identifiers checked.
- **LAB-T3 Receive / accession (P0):** scan accession → verify condition → accept or **reject** with reason (auto-notifies orderer, creates recollect task).
- **LAB-T4 Enter results (P0):** worklist by section/instrument; numeric validation (decimals, plausibility limits), auto-flag vs age/sex range, **delta check**, calculated analytes; manual entry or instrument import; reagent consumption posted once per order item via BOM (`CONSUMPTION` from laboratory location, FEFO); cancellation reverses.
- **LAB-T5 QC gate (P1):** if tenant enables, patient results for an analyte/instrument cannot be verified unless QC for the day is accepted (hard or soft block); Westgard rules evaluated (1-2s warn, 1-3s, 2-2s, R-4s, 4-1s, 10x); Levey-Jennings chart.
- **LAB-T6 Verify (P0):** by different user than enterer (configurable); pathologist required for configurable tests; verification unlocks release.
- **LAB-T7 Critical value (P0):** result with `LL/HH` → immediate in-app+SMS alert to responsible clinician and lab supervisor; notifier must record *who was notified, when, method, read-back*; unacknowledged alerts escalate (JOB-41).
- **LAB-T8 Release report (P0):** PDF with letterhead, patient, specimen info, results, reference ranges, flags, comments, signatures and PRC numbers; release to visit/patient portal/print; version + SHA-256.
- **LAB-T9 Amend/correct (P0):** only after release; reason required; new report version marked **CORRECTED**; orderer notified; previous version retained.
- **LAB-T10 Repeat/reflex (P1):** repeat test on abnormal; reflex rules (e.g., abnormal urinalysis → culture).
- **LAB-T11 Send-out (P2).**
- **LAB-T12 Confidential tests:** flagged tests hidden in general views; access needs `lab.result.view_confidential`, reason, and is logged; report release restricted to ordering clinician/patient per policy.
- **LAB-T13 Instrument interface (P2):** HL7 v2/ASTM inbound; match by accession; unmatched to exceptions queue.
- **TAT tracking:** order→collect, collect→receive, receive→verify, total; overdue STAT escalations (JOB-42).

---

## 9. M6 — Pharmacy

### 9.1 Entities

| Table | Key columns |
|---|---|
| `generic_names` | name, atc_code |
| `drug_products` | item_id (→ `items`), generic_id, brand_name, strength, dosage_form, route, pack_size, fda_reg_no, rx_required (`OTC/RX/CONTROLLED`), controlled_schedule, storage (room/cold), is_formulary, high_alert, allergy_class |
| `drug_interactions` | generic_a, generic_b, severity, advice (global + tenant overrides) |
| `pharmacy_price_rules` | item_id, markup_pct or fixed price, effective_from |
| `dispenses` | dispense_no, rx_id (nullable for OTC), patient_id, pharmacist_id, status (`DRAFT/VERIFIED/READY/DISPENSED/RETURNED/VOID`), total, counselling_done, notes |
| `dispense_items` | dispense_id, prescription_item_id, item_id, qty, batch_id, unit_price, substituted_from_item_id, override_reason |
| `pharmacist_interventions` | rx_id, type, description, outcome, by |
| `pharmacy_sales` (OTC) | sale_no, patient_id (optional), items, status — posted as dispense without Rx |
| `patient_returns` | dispense_item_id, qty, reason, disposition (`RESTOCK/QUARANTINE/DISPOSE`) |
| `controlled_register` | drug item_id, batch_id, entry_type, qty_in/out, running_balance, patient_id, rx_id, special_rx_no, prescriber_s2_no, pharmacist_id, witness_id, at |
| `special_rx_records` | special_rx_serial (unique per tenant), prescriber_id, s2_license_no, patient_id, drug, qty_words, qty_numeric, date_issued, copy_status |
| `medication_administrations` | visit_id, drug_item_id, batch_id, dose, route, given_by, at (in-clinic administration; posts `CONSUMPTION`) |
| `pharmacy_stock_requests` | → uses Supply requisitions (§10) |

Stock itself lives in the unified inventory (`items`, `stock_*`, location type `PHARMACY`).

### 9.2 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Generic names | ✔ | ✔ | ✔ | Archive | |
| Drug products | ✔ (also creates `items` row) | ✔ | ✔ | Archive (no stock) | FDA reg no. optional field |
| Interactions | ✔ | ✔ | ✔ | Archive | Tenant overrides of global set |
| Price rules | ✔ | ✔ | ✔ | Archive | |
| Dispense | ✔ | ✔ | ✔ while draft | Void (pre-posting) / Return | Posted = immutable |
| OTC sale | ✔ | ✔ | ✔ draft | Void | Controlled drugs blocked |
| Interventions | ✔ | ✔ | ✔ | — | |
| Patient return | ✔ | ✔ | — | — | |
| Controlled register | auto only | ✔ | — | — | **Append-only**; printable “Dangerous Drugs Book” |
| Special Rx record | ✔ | ✔ | ✔ before dispense | — | Unique serial |
| Medication administration | ✔ | ✔ | ✔ correction | Void | |

### 9.3 Transactional workflows

```mermaid
flowchart LR
  A[Rx ISSUED] --> B[Pharmacist verify<br/>allergy, interaction, dose, duplicates]
  B -->|intervene| C[Contact prescriber]
  B --> D[FEFO allocation]
  D --> E[Label + counsel]
  E --> F[Dispense - post stock + charge]
  F --> G[Rx DISPENSED / PARTIAL]
```

- **PHM-T1 Verify prescription (P0):** queue of issued Rx; checks: patient allergies, interactions, duplicate therapy, max daily dose, pediatric/geriatric flags, prescription validity, controlled-drug completeness. Pharmacist can *approve*, *intervene* (logged), or *reject* (reason to prescriber).
- **PHM-T2 Dispense (P0):** FEFO batch allocation (manual lot override logged) → quantity vs prescribed (partial fill allowed; remainder stays open until expiry) → generic substitution only if not DAW and patient consents → label printed (patient, drug, sig, batch, expiry, pharmacist) → counselling checkbox → **Post**: `DISPENSE` movements + balances + charge to invoice + Rx status update, all in one transaction.
- **PHM-T3 OTC / walk-in sale (P0):** scan/select items → FEFO → post `SALE` → invoice/payment.
- **PHM-T4 Controlled drug dispense (P0):** requires `pharmacy.controlled.dispense` + MFA step-up; validates special Rx serial (unique, not previously used, prescriber S2 license valid), patient ID captured, quantity in words = numerals, **no refill**, witness (second authorized user) co-signs; writes register entry with running balance; Rx cannot be reused.
- **PHM-T5 Patient return (P1):** only per policy (sealed, batch known, within N days) → `PATIENT_RETURN` to location (restock) or quarantine/dispose; credit note if paid.
- **PHM-T6 In-clinic administration (P1):** nurse/doctor administers from pharmacy/clinic stock → `CONSUMPTION` + MAR record + charge.
- **PHM-T7 Replenish pharmacy stock (P0):** create requisition to central store (§10 SUP-T3) or use par suggestion (JOB-30); receive & acknowledge.
- **PHM-T8 Expiry management (P0):** near-expiry dashboard (90/60/30 days); auto-quarantine expired (JOB-28); disposal via §10 SUP-T8; monthly expired-controlled-drug report (JOB-39).
- **PHM-T9 Controlled reconciliation (P0):** daily register vs on-hand (JOB-38); variance > 0 raises incident and blocks further dispensing of that drug until resolved by pharmacist-in-charge.
- **PHM-T10 Drug recall (P1):** §10 SUP-T9; lists patients dispensed from affected lots.

**Rules:** only pharmacists dispense prescription and controlled drugs; assistants prepare and sell OTC; every dispense stores batch/lot; pricing from price rules; senior/PWD discounts applied at billing with ID capture.

---

## 10. M7 — Central Supply

### 10.1 Entities

| Table | Key columns |
|---|---|
| `item_categories` | name, parent_id |
| `items` | code, name, item_type, category_id, base_uom_id, is_batch_tracked, is_expiry_tracked, storage_conditions, is_hazardous, gtin/barcode, standard_cost, min_shelf_life_days_on_receipt, is_active |
| `uoms` / `uom_conversions` | code, name; item_id, from_uom, to_uom, factor |
| `item_barcodes` | item_id, barcode, uom_id |
| `suppliers` | code, name, tin, address, terms_days, lead_time_days, rating, status; `supplier_contacts`; `supplier_items` (item, supplier sku, last_price, pack) |
| `stock_locations` | branch_id, type, name, parent_id, is_active (+ bins) |
| `location_item_params` | location_id, item_id, min_qty, max_qty, par_qty, reorder_point |
| `purchase_requests` / lines | pr_no, requester, location_id, status, needed_by, reason; item, qty, uom |
| `purchase_orders` / lines | po_no, supplier_id, branch_id, status, expected_date, terms, total, approved_by/at; item, qty_ordered, qty_received, unit_price, uom |
| `goods_receipts` / lines | grn_no, po_id (nullable), supplier_id, delivery_note_no, received_by/at, status (`DRAFT/POSTED/VOID`); item, qty, uom, lot_no, expiry_date, unit_cost, inspection_result (`ACCEPT/QUARANTINE/REJECT`), temperature_ok |
| `supplier_invoices` | invoice_no, po_id, grn_id, amount, match_status (`MATCHED/VARIANCE`) |
| `supplier_returns` / lines | rtv_no, supplier_id, reason, status, credit_note_ref |
| `requisitions` / lines | req_no, from_location_id (requester), to_location_id (supplier store), type (`ADHOC/PAR/STAT`), status, needed_by, approved_by; item, qty_requested, qty_approved, qty_issued, qty_received |
| `issues` / lines | issue_no, requisition_id, issued_by, status; item, batch_id, qty |
| `stock_transfers` | transfer_no, from_location, to_location, cross_branch, status |
| `stock_adjustments` / lines | adj_no, location_id, reason_code, status (`DRAFT/PENDING/POSTED/REJECTED`), requested_by, approved_by; item, batch_id, qty_delta |
| `physical_counts` / lines | count_no, location_id, type (full/cycle/spot), blind (bool), snapshot_at, status; item, batch_id, system_qty, counted_qty, recount_qty, variance |
| `disposals` / lines | disposal_no, reason (expired/damaged/recalled/contaminated), method, witness_ids, status; item, batch_id, qty, cost |
| `recalls` / `recall_batches` | recall_no, source (supplier/FDA/internal), reason, status; item, batch |
| `stock_batches`, `stock_balances`, `stock_movements`, `stock_reservations` | see architecture §8 |
| `consumption_logs` | location_id, item_id, batch_id, qty, ref_type (visit/lab/procedure/house), ref_id |
| `valuation_snapshots` | as_of, location_id, item_id, qty, value |

### 10.2 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Item categories, UOMs, conversions, barcodes | ✔ | ✔ | ✔ | Archive | |
| Items | ✔ | ✔ | ✔ (type & base UOM locked once stock exists) | Archive | |
| Suppliers (+contacts, supplier items) | ✔ | ✔ | ✔ | Archive | |
| Stock locations | ✔ | ✔ | ✔ | Archive (zero stock) | |
| Location item params (min/max/par) | ✔ | ✔ | ✔ | ✔ | Bulk import |
| Purchase request | ✔ | ✔ | ✔ draft | Cancel | |
| Purchase order | ✔ | ✔ | ✔ draft | Cancel | Approved PO amended via revision |
| Goods receipt | ✔ | ✔ | ✔ draft | Void (reversal) | |
| Supplier invoice | ✔ | ✔ | ✔ | Void | 3-way match |
| Supplier return | ✔ | ✔ | ✔ draft | Cancel | |
| Requisition | ✔ | ✔ | ✔ draft | Cancel | |
| Issue | ✔ | ✔ | ✔ draft | Void (reversal) | |
| Transfer | ✔ | ✔ | ✔ draft | Cancel | |
| Adjustment | ✔ | ✔ | ✔ draft | Reject / Void | Approval required |
| Physical count | ✔ | ✔ | ✔ counts | Cancel draft | |
| Disposal | ✔ | ✔ | ✔ draft | Void | Witness required |
| Recall | ✔ | ✔ | ✔ status/actions | Close | |
| Batches | auto (GRN) | ✔ | ✔ status (quarantine/release) | — | |
| Stock movements | auto only | ✔ | — | — | Append-only |
| Consumption logs | ✔ | ✔ | — | Void | |

### 10.3 Transactional workflows

- **SUP-T1 Purchase request → purchase order (P0):** PR (Draft → Submitted → Approved/Rejected) → convert to PO (by supplier, price from `supplier_items`) → PO Draft → **Pending approval** (amount thresholds → approver chain) → Approved → Sent (PDF/email) → Partially Received → Received → Closed / Cancelled. Approved PO edits require revision + re-approval. Reorder suggestions (JOB-31) pre-fill PRs.
- **SUP-T2 Receive goods / GRN (P0):** against PO or direct (permission) → per line capture lot, expiry, qty, UOM, cost, inspection (accept / quarantine / reject), cold-chain temp → validate **min remaining shelf life** (tenant rule, override with reason) → over-receipt tolerance → **Post**: `GRN` movements into receiving location (or `QUARANTINE`), PO lines updated, cost set on batch, label/barcode print. Void creates reversal if stock still on hand.
- **SUP-T3 Requisition → issue → receive (P0):** department creates requisition (manual, from par list, or STAT) → approval (optional by amount/category) → supply officer **picks** (FEFO suggested) → **Issue** posts `ISSUE_OUT` from central store and `ISSUE_IN` to `IN_TRANSIT` → requester **acknowledges receipt** (full/partial/discrepancy) → `ISSUE_IN` to destination location. Unreceived after SLA escalates (JOB-35). Same-branch auto-receive can be enabled per tenant.
- **SUP-T4 Inter-location/inter-branch transfer (P1):** same mechanics as SUP-T3, initiated by source; cross-branch requires both branch approvals.
- **SUP-T5 Stock adjustment (P0):** reason codes (damage, loss, found, correction, sample, other) → Draft → Pending → **Approved & Posted** by a different user (SoD), value thresholds → `ADJ_GAIN/ADJ_LOSS` movements. Controlled drugs also write the register.
- **SUP-T6 Physical / cycle count (P0):** create sheet (full, cycle by ABC class, spot) → snapshot system qty (blind count hides it) → count entry (mobile scan) → auto-recount for variance above threshold → review → approval → `COUNT_VARIANCE` movements. Cycle counts scheduled (JOB-33).
- **SUP-T7 Return to supplier (P1):** Draft → Approved → Posted (`SUPPLIER_RETURN` movement) → Credit note received → Closed.
- **SUP-T8 Disposal / waste (P0):** expired/damaged/recalled batches → Draft → witness signoff (controlled drugs: two witnesses) → **Post** `DISPOSAL` from source to `WASTE` (or direct) → certificate PDF.
- **SUP-T9 Recall (P0):** create recall by item + lot(s) → system lists on-hand by location, issued/dispensed quantities and **patients/visits** (for drugs) → batches set `RECALLED` (auto-blocks use) → action checklist (quarantine, return, notify prescribers/patients) → close with evidence.
- **SUP-T10 Consumption posting (P0):** from visit supplies, lab BOM, pharmacy administration, or “house use” entries → FEFO → `CONSUMPTION`.
- **SUP-T11 Par replenishment (P1):** locations counted (scan/two-bin) → below par → requisition auto-drafted (JOB-30) up to max.
- **SUP-T12 Batch quarantine/release (P0):** QA hold (e.g., damaged packaging) → status change logged; release requires approver.
- **SUP-T13 Valuation & month-end (P1):** snapshot (JOB-37); period lock prevents backdated postings.

**Rules**
- SUP-R1 No negative stock; issue ≤ available (on-hand − reserved).
- SUP-R2 Base-UOM storage; all UOM conversions explicit and audited.
- SUP-R3 Expiry-tracked items require expiry on receipt; expiry < today + min shelf life blocks (override logged).
- SUP-R4 Lot numbers unique per (item, supplier, lot, expiry).
- SUP-R5 Posted documents immutable; period lock honored.
- SUP-R6 Purchasing thresholds and approvers configurable per tenant.

---

## 11. M8 — Billing & Cashiering (supporting)

### 11.1 Entities

| Table | Key columns |
|---|---|
| `invoices` | invoice_no, patient_id, visit_id, branch_id, status (`DRAFT/OPEN/PARTIAL/PAID/VOID`), subtotal, discount_total, tax_total, total, balance, issued_at |
| `invoice_lines` | invoice_id, source_type (service/lab/pharmacy/supply), source_id, description, qty, unit_price, discount_type_id, discount_amount, tax_code |
| `payments` | payment_no/OR no, invoice_id, method_id, amount, reference, received_by, shift_id, received_at, status |
| `payment_allocations` | payment_id, invoice_id, amount |
| `credit_notes` / refunds | cn_no, invoice_id, reason, amount, approved_by, status |
| `cashier_shifts` | cashier_id, opened_at, opening_cash, closed_at, counted_cash, variance, status |
| `discount_applications` | invoice_line_id, discount_type_id, id_number, id_type, verified_by |

### 11.2 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Invoice | ✔ auto/manual | ✔ | ✔ draft | Void (reason, approval) | |
| Invoice lines | ✔ auto from charges | ✔ | ✔ draft | Remove draft | |
| Payment | ✔ | ✔ | — | Void (reason, approval) | |
| Credit note/refund | ✔ | ✔ | — | Cancel draft | |
| Cashier shift | ✔ open | ✔ | close | — | |
| Discount application | ✔ | ✔ | — | Revoke before payment | ID number captured |

### 11.3 Workflows
- **BIL-T1 Charge capture:** services, lab tests, dispensed drugs, procedures, supplies post charge lines to the visit's open invoice (created on demand).
- **BIL-T2 Discounts:** senior/PWD/promo/staff with required ID capture; rules and limits configurable (legal basis stored).
- **BIL-T3 Payment:** split tender, partial payments, running balance, receipt PDF/thermal.
- **BIL-T4 Void/refund:** reason + supervisor step-up; posts reversal; if tied to stock-moving lines, prompts return/restock decision.
- **BIL-T5 Shift open/close:** opening cash, blind close count, variance recorded.
- **BIL-T6 Daily close:** JOB-48 summarizes collections and locks the day.
- **Open question:** BIR-accredited receipting/invoicing (CAS/EIS) is a separate compliance track — see todo.md.

---

## 12. M9 — Compliance & Audit

### 12.1 Entities

| Table | Key columns |
|---|---|
| `audit_log` | occurred_at, actor_type, actor_id, acting_as_platform, breakglass_id, action, entity_type, entity_id, before, after, request_id, ip, user_agent, prev_hash, row_hash |
| `phi_access_log` | user_id, patient_id, resource_type/id, action, purpose, at, breakglass_id |
| `consent_templates` | version, title, body, purposes[], locale, effective_from |
| `data_subject_requests` | patient_id, type (access/correction/erasure/objection/portability), status (`RECEIVED/VERIFYING/IN_PROGRESS/COMPLETED/REJECTED`), due_at, handled_by, outcome_note |
| `breach_incidents` | detected_at, description, data_classes, affected_count, status (`DETECTED/ASSESSED/NOTIFIED/CLOSED`), notify_regulator_due_at, notified_at, corrective_actions |
| `retention_policies` | record_class, retention_years, action (archive/anonymize/delete), legal_basis |
| `legal_holds` | scope, reason, placed_by, released_at |
| `security_events` | type (login_fail, lockout, mfa_reset, role_change, rls_canary_fail), user/tenant, detail |
| `access_reviews` | campaign, reviewer, user_id, decision, decided_at |

### 12.2 CRUD

| Entity | C | R | U | D | Notes |
|---|---|---|---|---|---|
| Audit log, PHI access log, security events | auto | ✔ (DPO/auditor/admin) | — | — | Append-only; REVOKE UPDATE/DELETE |
| Consent templates | ✔ | ✔ | ✔ new version | Archive | |
| Data subject requests | ✔ | ✔ | ✔ workflow | — | |
| Breach incidents | ✔ | ✔ | ✔ | — | |
| Retention policies, legal holds | ✔ | ✔ | ✔ | Release | |
| Access reviews | ✔ | ✔ | ✔ decision | — | |

### 12.3 Workflows
- **CMP-T1 DSR handling:** intake → identity verification → collect data (export pack generated via RLS-scoped query) → respond within SLA (reminders JOB-16). Erasure = anonymize identifiers while preserving legally required clinical/financial records; blocked by legal hold.
- **CMP-T2 Breach response:** detect (manual or automated from security events) → assess severity → timers for regulator/data-subject notification (JOB-17) → notify → remediate → close with lessons learned.
- **CMP-T3 Access recertification:** see ADM-T5.
- **CMP-T4 Audit review:** saved queries per patient/user/entity; export for regulator requests.
- **CMP-T5 Retention review:** JOB-15 produces candidate list; DPO approves; actions logged.

---

## 13. M10 — Notifications

| Table | Key columns |
|---|---|
| `notifications` | user_id, type, title, body, link, severity, read_at |
| `notification_preferences` | user_id, event, channels, quiet_hours |
| `outbox` | event_type, payload, status, attempts, available_at |
| `delivery_log` | channel, recipient, provider_id, status, error, sent_at |

CRUD: notifications (auto create / read / mark read / dismiss), preferences (CRU), templates (see §5), delivery log (read-only).
Event catalog (examples): appointment reminder, result ready, **critical value**, specimen rejected, Rx ready, low stock, near-expiry, PO approval needed, requisition issued/overdue, count scheduled, license expiring, DSR due, breach clock, subscription expiring.

---

## 14. Background Job Catalog

Legend — **Type:** S = scheduled cron (per tenant timezone unless noted), E = event-driven, D = delayed. **Scope:** T = per tenant (fan-out), P = platform. All handlers are idempotent with retries (exponential backoff, max shown) and a dead-letter queue.

| ID | Job | Module | Type | Schedule / trigger | Scope | What it does | Retries |
|---|---|---|---|---|---|---|---|
| JOB-01 | `outbox.dispatch` | Core | S | every 5 s | P | Publishes outbox events to queues/notifications | ∞ |
| JOB-02 | `notification.send` | Core | E | on notification created | T | Sends email/SMS/push; logs delivery; honors quiet hours (critical bypasses) | 8 |
| JOB-03 | `tenant.provision` | Platform | E | tenant created | T | Seeds roles, branch, locations, masters, sequences; invites admin | 5 |
| JOB-04 | `tenant.export` | Platform | E | request / offboard | T | Builds encrypted export through RLS-scoped queries | 3 |
| JOB-05 | `tenant.offboard.purge` | Platform | S | daily 02:00 | P→T | Purges tenants past retention hold; deletes objects; signed log | 3 |
| JOB-06 | `subscription.check` | Platform | S | daily 00:30 | P | Flags expiring/expired subscriptions; grace; suspends per policy | 3 |
| JOB-07 | `usage.metering` | Platform | S | daily 01:00 | P→T | Counts users, patients, rows, storage, API calls per tenant | 3 |
| JOB-08 | `audit.partition.maintain` | Core | S | monthly (day 25) | P | Creates next partitions for audit/ledger/notification tables | 5 |
| JOB-09 | `audit.archive` | Core | S | monthly | P | Moves old partitions to cold storage per retention | 3 |
| JOB-10 | `audit.integrity.verify` | Compliance | S | daily 03:00 | T | Verifies hash chain; raises security event on break | 3 |
| JOB-11 | `session.cleanup` | IAM | S | hourly | P | Deletes expired sessions/tokens/invites | 3 |
| JOB-12 | `user.inactive.deactivate` | IAM | S | daily | T | Deactivates users inactive > N days (tenant policy) after warning | 3 |
| JOB-13 | `credential.expiry.remind` | IAM | S | daily 07:00 | T | Reminds about password expiry and PRC/S2/PDEA license expiry (60/30/7 days) | 3 |
| JOB-14 | `backup.verify` | Ops | S | weekly | P | Restores latest backup to sandbox; runs integrity checks; reports | 2 |
| JOB-15 | `retention.enforce` | Compliance | S | monthly | T | Lists records past retention for DPO approval; anonymizes approved; honors legal holds | 3 |
| JOB-16 | `dsr.deadline.remind` | Compliance | S | daily | T | Reminds handlers of DSRs nearing SLA | 3 |
| JOB-17 | `breach.clock.remind` | Compliance | S | every 15 min | T | Escalates open breach incidents approaching notification deadline | 3 |
| JOB-18 | `rls.canary` | Security | S | hourly | P | Canary tenants A/B probe: A cannot read B; alerts on any leak | 1 |
| JOB-19 | `report.materialized.refresh` | Reports | S | nightly 02:30 | T | Refreshes materialized views for heavy reports | 3 |
| JOB-20 | `report.scheduled.deliver` | Reports | S | per user schedule | T | Generates and emails scheduled reports (PDF/XLSX) | 5 |
| JOB-21 | `report.export.generate` | Reports | E | export requested | T | Async large export to file; notifies user | 3 |
| JOB-22 | `patient.duplicate.detect` | Patients | S | nightly | T | Finds probable duplicate patients; queues for merge review | 3 |
| JOB-23 | `appointment.reminder` | Clinical | S | every 15 min | T | SMS/email reminders (24 h and 2 h before) | 5 |
| JOB-24 | `appointment.noshow.mark` | Clinical | S | hourly | T | Marks past un-checked-in appointments as NO_SHOW after grace | 3 |
| JOB-25 | `visit.stale.close` | Clinical | S | nightly 23:30 | T | Flags/closes visits open beyond policy; lists exceptions | 3 |
| JOB-26 | `rx.expire` | Clinical | S | daily | T | Expires issued prescriptions past `valid_until` | 3 |
| JOB-27 | `stock.expiry.scan` | Supply | S | daily 01:00 | T | Flags batches at 90/60/30 days; creates alerts; builds near-expiry worklist | 3 |
| JOB-28 | `stock.expiry.quarantine` | Supply | S | daily 00:05 | T | Sets expired batches to `EXPIRED` and moves availability to zero; notifies | 3 |
| JOB-29 | `stock.lowlevel.scan` | Supply | S | every 4 h | T | Detects below-min/out-of-stock; notifies custodians | 3 |
| JOB-30 | `par.replenishment.suggest` | Supply | S | daily 06:00 | T | Drafts requisitions for locations below par | 3 |
| JOB-31 | `po.reorder.suggest` | Supply | S | daily 06:30 | T | Drafts PRs from reorder points, usage and lead time | 3 |
| JOB-32 | `stock.balance.reconcile` | Supply | S | nightly 03:30 | T | Recomputes balances from ledger; mismatch ⇒ alert + hold | 2 |
| JOB-33 | `stock.count.remind` | Supply | S | weekly | T | Schedules/reminds cycle counts by ABC class | 3 |
| JOB-34 | `po.overdue.remind` | Supply | S | daily | T | Flags POs past expected date; notifies purchaser | 3 |
| JOB-35 | `requisition.sla.escalate` | Supply | S | every 30 min | T | Escalates unapproved/unissued/unreceived requisitions per SLA | 3 |
| JOB-36 | `supplier.scorecard.compute` | Supply | S | monthly | T | Lead time, fill rate, reject rate per supplier | 3 |
| JOB-37 | `valuation.snapshot` | Supply | S | daily 23:55 (+month-end lock) | T | Stores stock valuation per location/item | 3 |
| JOB-38 | `controlled.reconcile` | Pharmacy | S | daily 22:00 | T | Register running balance vs on-hand; variance ⇒ incident + block | 3 |
| JOB-39 | `controlled.report.generate` | Pharmacy | S | monthly / semi-annual | T | Builds controlled-drug and expired-controlled reports for regulatory submission | 3 |
| JOB-40 | `pharmacy.rx.pending.remind` | Pharmacy | S | every 15 min | T | Flags Rx awaiting verification/dispensing beyond target | 3 |
| JOB-41 | `lab.critical.escalate` | Lab | S | every 1 min | T | Escalates unacknowledged critical values (clinician → lab manager → branch manager) | 3 |
| JOB-42 | `lab.tat.monitor` | Lab | S | every 5 min | T | Detects STAT/routine orders exceeding TAT; alerts | 3 |
| JOB-43 | `lab.report.render` | Lab | E | result verified/released/amended | T | Renders PDF, stores with hash, triggers distribution | 5 |
| JOB-44 | `lab.qc.missing.remind` | Lab | S | daily at section start | T | Reminds when daily QC not recorded | 3 |
| JOB-45 | `lab.specimen.stale.flag` | Lab | S | hourly | T | Flags uncollected/unreceived/unprocessed specimens beyond stability | 3 |
| JOB-46 | `lab.instrument.calibration.remind` | Lab | S | daily | T | Calibration/maintenance due reminders | 3 |
| JOB-47 | `lab.interface.poll` | Lab | S | every 30 s (P2) | T | Retries/processes inbound HL7/ASTM messages; unmatched ⇒ exceptions | 10 |
| JOB-48 | `billing.daily.close` | Billing | S | nightly 23:59 | T | Summarizes collections, flags open shifts, locks day | 3 |
| JOB-49 | `billing.overdue.flag` | Billing | S | daily | T | Flags unpaid balances; reminders | 3 |
| JOB-50 | `billing.receipt.generate` | Billing | E | payment posted | T | Renders receipt PDF/thermal payload | 5 |

**Job rules:** payload always `{tenantId, branchId?, idempotencyKey, params}`; handlers run in `withTenant`; fan-out coordinators enumerate only active tenant IDs; per-tenant concurrency cap; all executions recorded in `job_runs` (visible in Platform Console); failures beyond retries land in DLQ with alerts.

---

## 15. Report Catalog

**Common behavior:** date range, branch filter (tenant-wide for admins), tenant timezone, sort, totals; output **screen, CSV, XLSX, PDF**; print-friendly; saved filters; schedulable (JOB-20); large exports async (JOB-21); every report runs under RLS (read replica with `clinic_report` role); PHI-bearing reports log to `phi_access_log`.

### 15.1 Platform (superadmin; aggregate only, no patient identifiers)

| ID | Report | Key filters / content |
|---|---|---|
| RPT-PLT-01 | Tenant registry & status | status, plan, created date, branches, users |
| RPT-PLT-02 | Tenant usage | users, patients, storage, API calls, jobs per tenant |
| RPT-PLT-03 | Subscriptions & renewals | expiring, expired, plan mix |
| RPT-PLT-04 | Cross-tenant user directory | tenant, role, status, last login, MFA |
| RPT-PLT-05 | Break-glass access log | tenant, superadmin, reason, duration, actions |
| RPT-PLT-06 | Platform audit log | actor, action, entity, date |
| RPT-PLT-07 | Job health | queue depth, failures, DLQ, schedule adherence |
| RPT-PLT-08 | Security events | failed logins, lockouts, MFA resets, RLS canary |

### 15.2 Tenant administration

| ID | Report | Content |
|---|---|---|
| RPT-ADM-01 | User directory & roles | branch, role, status, MFA |
| RPT-ADM-02 | User activity | logins, actions by user/module |
| RPT-ADM-03 | Data-change audit | entity, before/after, actor |
| RPT-ADM-04 | License & credential expiry | PRC/S2/PDEA, passwords |
| RPT-ADM-05 | Settings change history | who changed what |

### 15.3 Clinical

| ID | Report | Content |
|---|---|---|
| RPT-CLN-01 | Daily census / patient log | visits by branch/day, status |
| RPT-CLN-02 | Visit volume trend | day/week/month, by service/practitioner |
| RPT-CLN-03 | New vs returning patients | counts, rates |
| RPT-CLN-04 | Top diagnoses (ICD-10) | by period, age group, sex |
| RPT-CLN-05 | Patient demographics | age/sex/location distribution |
| RPT-CLN-06 | Appointment utilization & no-show | slots used, cancellations, no-show rate |
| RPT-CLN-07 | Consultations by practitioner | counts, avg duration |
| RPT-CLN-08 | Referral log | destination, reason, status |
| RPT-CLN-09 | Medical certificate register | numbered, issuer, type |
| RPT-CLN-10 | Notifiable / communicable disease list | configured ICD-10 set, counts by week |
| RPT-CLN-11 | Immunization register | vaccine, lot, dose, patient |
| RPT-CLN-12 | Queue waiting time | wait by service/hour |

### 15.4 Laboratory

| ID | Report | Content |
|---|---|---|
| RPT-LAB-01 | Daily worklist / pending tests | by section, priority, age of order |
| RPT-LAB-02 | Test volume | by test/panel/section/period |
| RPT-LAB-03 | Turnaround time | median/90th percentile by test, priority, stage |
| RPT-LAB-04 | Critical value log | detected→notified→acknowledged times, who |
| RPT-LAB-05 | Rejected specimens | reasons, collector, trends |
| RPT-LAB-06 | Abnormal results summary | by test, flag rate |
| RPT-LAB-07 | Corrected/amended reports log | reason, before/after, notified |
| RPT-LAB-08 | QC summary & Levey-Jennings | per analyte/level, rule violations, corrective actions |
| RPT-LAB-09 | Reagent consumption vs tests | BOM expected vs actual, variance |
| RPT-LAB-10 | Lab revenue | by test/section/payer |
| RPT-LAB-11 | Patient cumulative results | trended analytes per patient |
| RPT-LAB-12 | Specimen chain-of-custody | full event trail per accession |
| RPT-LAB-13 | Workload by technologist | results entered/verified |
| RPT-LAB-14 | Send-out tracking | status, TAT |

### 15.5 Pharmacy

| ID | Report | Content |
|---|---|---|
| RPT-PHM-01 | Daily dispensing log | patient, drug, batch, qty, pharmacist |
| RPT-PHM-02 | Prescription record book | chronological Rx register (printable) |
| RPT-PHM-03 | **Dangerous Drugs Book / controlled register** | per drug, running balance, special-Rx refs, witness |
| RPT-PHM-04 | Controlled-drug periodic report | monthly/semi-annual submission format (configurable) |
| RPT-PHM-05 | Stock on hand by batch | location, expiry, cost |
| RPT-PHM-06 | Stock card (drug) | full ledger with running balance |
| RPT-PHM-07 | Near-expiry (90/60/30) & expired | value at risk, action status |
| RPT-PHM-08 | Low/out-of-stock | vs min/reorder |
| RPT-PHM-09 | Fast/slow moving & ABC/VEN | turnover, classification |
| RPT-PHM-10 | OTC & Rx sales summary | by drug, cashier, period |
| RPT-PHM-11 | Dispensing by prescriber | counts, top drugs |
| RPT-PHM-12 | Drug utilization by generic | volumes, costs |
| RPT-PHM-13 | Substitutions & interventions | counts, outcomes |
| RPT-PHM-14 | Returns & disposals | reasons, value |
| RPT-PHM-15 | Stock valuation | by location/category |
| RPT-PHM-16 | Controlled variance/incident log | discrepancies and resolutions |

### 15.6 Central supply

| ID | Report | Content |
|---|---|---|
| RPT-SUP-01 | Stock on hand | by location/category/item/batch |
| RPT-SUP-02 | Stock ledger / stock card | item or batch movement history |
| RPT-SUP-03 | Movement summary | receipts, issues, adjustments, consumption by period |
| RPT-SUP-04 | GRN register | by supplier/PO/date, rejects |
| RPT-SUP-05 | PO status & aging | open, partial, overdue, value |
| RPT-SUP-06 | Pending requisitions | by department, age, SLA breach |
| RPT-SUP-07 | Requisition fulfillment & turnaround | fill rate, request→issue→receive times |
| RPT-SUP-08 | Par-level compliance | below par, stock-outs by location |
| RPT-SUP-09 | Consumption by department/item | trends, cost |
| RPT-SUP-10 | Reorder report | suggested qty, lead time, supplier |
| RPT-SUP-11 | Dead/slow/excess stock | no movement N days, over max |
| RPT-SUP-12 | Expiry & disposal/waste | value, reasons |
| RPT-SUP-13 | Adjustments & variances | reason, approver, value |
| RPT-SUP-14 | Physical count sheets & variance | blind sheets; variance by item |
| RPT-SUP-15 | Supplier performance | lead time, fill rate, reject rate, price changes |
| RPT-SUP-16 | Recall trace | lots → locations → patients/visits |
| RPT-SUP-17 | Stock valuation & month-end | per location, snapshots |
| RPT-SUP-18 | Inter-location transfers | in-transit, discrepancies |

### 15.7 Billing

| ID | Report | Content |
|---|---|---|
| RPT-BIL-01 | Daily collections (Z-report) | by method, cashier, branch |
| RPT-BIL-02 | Revenue by service/department | clinical, lab, pharmacy, procedures |
| RPT-BIL-03 | Receivables / unpaid balances | aging |
| RPT-BIL-04 | Discounts given | senior/PWD/promo with ID refs |
| RPT-BIL-05 | Void/refund log | reason, approver |
| RPT-BIL-06 | Cashier shift report | opening, counted, variance |
| RPT-BIL-07 | Invoice register | numbering continuity |
| RPT-BIL-08 | Revenue vs cost (pharmacy/supply margin) | item-level margin |

### 15.8 Compliance

| ID | Report | Content |
|---|---|---|
| RPT-CMP-01 | PHI access log by patient | who viewed what/when/why |
| RPT-CMP-02 | PHI access by user | anomaly flags |
| RPT-CMP-03 | Consent status | missing/expired/withdrawn |
| RPT-CMP-04 | DSR register | SLA status |
| RPT-CMP-05 | Breach register | timeline, notifications |
| RPT-CMP-06 | Access recertification | campaign outcomes |
| RPT-CMP-07 | Restricted-record & confidential-result access | reasons |
| RPT-CMP-08 | Retention candidates & legal holds | pending actions |

**Dashboards** (role-based widgets; not reports): Admin (users, usage, alerts), Doctor (today's queue, pending results), Lab (pending by TAT, critical alerts), Pharmacy (Rx queue, near-expiry), Supply (low stock, open POs/requisitions), Cashier (shift totals), Superadmin (tenant health, jobs, security).

---

## 16. Non-Functional Requirements

| Area | Requirement |
|---|---|
| Sizing assumptions | 200 tenants, ≤ 300 concurrent users per large tenant, 2 M patients platform-wide, 50 M stock movements/yr (partitioned) |
| Performance | p95 < 300 ms CRUD, < 1 s search; reports < 10 s (p95) for 1-year range via replica/materialized views |
| Availability | 99.9 % monthly; RPO ≤ 5 min; RTO ≤ 1 h |
| Security | OWASP ASVS L2; MFA for privileged roles; encryption in transit/at rest; no PHI in logs |
| Privacy | DPA-aligned: consent, purpose logging, access logs, DSR, breach workflow, retention, processor agreement |
| Usability | Mobile-first; WCAG 2.1 AA; en + fil; ≤ 3 taps for primary actions on mobile |
| Browser/device | Latest 2 versions Chrome/Edge/Safari/Firefox; iOS Safari 16+, Android Chrome; barcode scan via camera |
| Data integrity | Immutable ledgers, optimistic locking, idempotent postings, nightly reconcile |
| Maintainability | Modular monolith, typed contracts, ≥ 80 % unit coverage on domain logic, isolation tests as release gate |
| Localization | PHP currency, PSGC addresses, `Asia/Manila` default, date formats per locale |
| Observability | Metrics/logs/traces with tenant labels; job and isolation dashboards |

---

## 17. Acceptance Scenarios (selected, Gherkin-style)

1. **Tenant isolation (P0):** *Given* tenants A and B with patients, *when* a user of A requests `GET /patients/{B-patient-id}`, *then* 404; listing returns only A rows; forging `tenant_id` in a POST body is ignored/rejected; a direct SQL test as `clinic_app` with A's context returns zero B rows.
2. **Forgotten context fails closed (P0):** *Given* a query executed without tenant context, *then* it returns zero rows and inserts fail `WITH CHECK`.
3. **Superadmin provisioning (P0):** *When* superadmin creates tenant “Acme Clinics” with admin email, *then* tenant is `ACTIVE`, seeded, the admin receives an invite, and superadmin sees the tenant and its admin in the directory.
4. **Enter clinic (P0):** *When* superadmin enters tenant A with a reason, *then* a time-boxed session exists, UI shows banner, every action carries `breakglass_id`, tenant admin is notified, and the token cannot read tenant B.
5. **FEFO (P0):** *Given* two batches (expiring Nov and Jan), *when* pharmacist dispenses 10 units, *then* stock is taken from the Nov batch first; expired/quarantined batches are never chosen.
6. **No oversell under concurrency (P0):** *Given* 5 units on hand, *when* two dispenses of 4 run simultaneously, *then* exactly one succeeds; the other gets `STOCK_INSUFFICIENT`.
7. **Controlled drug (P0):** *When* a controlled Rx is dispensed, *then* special-Rx serial, S2 license, quantity words/numerals, witness, and register entry are recorded; re-using the same Rx or serial is rejected; refill attempts are blocked.
8. **Receiving with shelf-life rule (P0):** *Given* min shelf life 180 days, *when* a GRN line expires in 90 days, *then* posting is blocked unless an authorized override reason is given.
9. **Requisition flow (P0):** *When* pharmacy requests 100 units, *then* the supply officer issues FEFO batches to in-transit and pharmacy acknowledgment moves stock into the pharmacy location; discrepancies are recorded.
10. **Lab critical value (P0):** *When* potassium result is flagged HH, *then* clinician and supervisor are alerted, a notification record with read-back is required, and unacknowledged alerts escalate after the configured minutes.
11. **Result integrity (P0):** *Given* a released report, *when* a value is corrected, *then* a new CORRECTED version is produced, previous kept, amendment logged with reason, and orderer notified.
12. **Immutable ledger (P0):** *When* any user/DB role attempts `UPDATE` or `DELETE` on `stock_movements`, *then* it is denied.
13. **Reconcile (P1):** *When* balance is tampered in a test, *then* JOB-32 detects mismatch, alerts, and holds the item.
14. **Audit chain (P1):** *When* an audit row is altered in a test DB, *then* JOB-10 reports a chain break.
15. **DSR (P1):** *When* a patient requests their data, *then* the request is tracked with a due date, the export contains only that patient's records, and the access is logged.
