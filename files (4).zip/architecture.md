# Multi-Tenant Clinic Platform — Architecture

**Version:** 1.0 (draft for engineering review) · **Date:** 2026-09-30
**Companion docs:** [specification.md](specification.md) · [frontend.md](frontend.md) · [todo.md](todo.md)

---

## 1. Purpose & Scope

A SaaS platform on which many independent clinic organizations (**tenants**) run their operations on one deployment, with **strict, database-enforced data separation** between tenants.

Modules in scope:

| Module | Summary |
|---|---|
| Platform Console | Superadmin: create/suspend tenants, create tenant admins, enter any clinic (audited), platform reports |
| Tenant Administration | Branches, users, roles, settings, master data |
| Patients & Clinical | Master patient index, appointments, visits, notes, prescriptions, orders |
| **Central Supply** | Item master, suppliers, PR/PO, receiving, requisitions, issues, transfers, counts, disposal, recalls |
| **Laboratory** | Test catalog, orders, specimens, results, verification, critical values, QC, reports |
| **Pharmacy** | Drug master, prescription verification, FEFO dispensing, OTC sales, controlled-drug register |
| Billing (supporting) | Charges, invoices, payments, discounts, cashier shifts |
| Compliance & Audit | Audit trail, PHI access log, consents, data-subject requests, breach register |
| Background Jobs | 50 scheduled/event jobs (catalog in specification §5) |

Out of scope for v1 (tracked in todo.md "Later"): inpatient/ADT, HMO claims engine, BIR-accredited invoicing, imaging/PACS, instrument middleware beyond HL7/ASTM basics.

---

## 2. Design Principles (research-informed)

Findings from the research pass that shaped the design (sources in §21):

1. **Shared schema + `tenant_id` on every row + PostgreSQL Row-Level Security** is the recommended default for a B2B SaaS on Postgres. RLS acts as the infrastructure safety net; application-level filtering still targets the tenant explicitly (defense in depth, not either/or).
2. **Enable `FORCE ROW LEVEL SECURITY`**, run the app as a non-owner, non-`BYPASSRLS` role, and set tenant context with **transaction-local** settings so pooled connections cannot leak a previous tenant's context. Composite PK/FKs should include `tenant_id`, and CI must run cross-tenant negative tests.
3. **Beware `SECURITY DEFINER` functions** — they bypass RLS. We avoid them.
4. **Pharmacy stock is managed at batch level under FEFO** (first-expired-first-out) because expiry varies by batch, not product; alert at 90/60/30 days before expiry and quarantine near-expired stock.
5. **Central supply uses par / min-max replenishment** with requisitions from departments and perpetual inventory with cycle counts; lot-level recall tracing is a first-class need.
6. **Laboratory:** a complete, timestamped audit trail from order to report; two-step entry/verification with delta and critical-value checks; critical-value notification logging; LOINC-coded tests; HL7 v2 (ORM/ORU) and FHIR `DiagnosticReport` for interoperability.
7. **Philippines regulatory context:** health data is *sensitive personal information* under the Data Privacy Act (RA 10173); clinics/labs are Personal Information Controllers and this platform is their Processor. Dangerous drugs (RA 9165) require special-prescription handling, no refills, dispensing/record-keeping and periodic reporting. Specific legal periods and forms **must be confirmed with counsel/DPO** and are therefore configuration, not hard-coded.
8. **Job queue on Postgres (pg-boss)** avoids a Redis dependency and gives transactional guarantees (`SKIP LOCKED`, exactly-once delivery, cron scheduling, retries). Throughput needs here are modest.

**Guiding rules**

- Isolation is enforced in **five layers** (§5), never by one.
- Stock changes are **append-only ledger entries**; balances are derived and reconcilable.
- Posted documents are immutable; corrections are reversals/amendments with reasons.
- Every PHI read and every write is attributable to a user, tenant, request, and (if applicable) a break-glass session.
- Modular monolith first; extract services only when measurements demand it.

---

## 3. Technology Stack & Decisions

| Concern | Choice | Rationale / ADR |
|---|---|---|
| Database | **PostgreSQL 17+** | RLS, partitioning, JSONB, FTS, `pg_trgm`, `SKIP LOCKED` |
| Backend | **Node.js (LTS) + TypeScript + NestJS** (Fastify adapter) | Modular structure, DI, OpenAPI generation, mature ecosystem |
| DB access | `node-postgres` + **Drizzle ORM** for typed queries; SQL-first migrations (dbmate / node-pg-migrate) | Explicit transactions for `SET LOCAL`; RLS DDL written as plain SQL |
| Job queue | **pg-boss** (Postgres-backed) | No extra infrastructure; cron + retries + singleton jobs |
| Frontend | **React 19 + TypeScript + Vite**, **React-Bootstrap / Bootstrap 5.3** (SCSS themed) | Requested stack; mobile-first grid, dark mode via `data-bs-theme` |
| Server state | TanStack Query | Cache keys carry `tenantId` |
| PDF/labels | Headless Chromium (Playwright) in a worker; ZPL/ESC-POS for labels/receipts | Letterhead reports, barcode labels |
| Object storage | S3-compatible (MinIO in dev) | Tenant-prefixed keys, pre-signed URLs |
| Auth | Argon2id passwords, TOTP MFA, short-lived JWT access + rotating refresh (httpOnly cookie) | §10 |
| Observability | OpenTelemetry → Prometheus/Grafana/Loki (or vendor) | `tenant_id` as a label, never PHI |
| Deploy | Docker images; Kubernetes or container platform; managed Postgres + PgBouncer (transaction mode) | §18 |
| Email / SMS | Provider abstraction (SMTP/API; local PH SMS gateway) | Outbox-driven |

**Key ADRs**

| # | Decision | Alternatives rejected |
|---|---|---|
| ADR-1 | Shared DB/schema with RLS | Schema-per-tenant (migration fan-out pain), DB-per-tenant (cost) — kept as *promotion path* for very large/regulated tenants via a tenant routing table |
| ADR-2 | Tenant → Branch → Stock Location hierarchy | Flat "clinic" = tenant (cannot model multi-branch companies) |
| ADR-3 | Single inventory ledger shared by Supply, Pharmacy, Lab | Separate stock tables per module (reconciliation drift) |
| ADR-4 | Superadmin enters a clinic via an audited *context switch* (“break-glass”) rather than a blanket cross-tenant PHI read | Policy `OR is_superadmin` on PHI tables (one bug = cross-tenant leak) |
| ADR-5 | pg-boss over BullMQ | Redis adds an operational dependency with no needed throughput gain |
| ADR-6 | Modular monolith + separate worker process (same codebase) | Microservices (premature) |
| ADR-7 | Append-only `stock_movements` + derived `stock_balances` with `CHECK (qty_on_hand >= 0)` | Mutable quantity column only (no audit, no reconciliation) |

---

## 4. System Context & Containers

```mermaid
flowchart LR
  subgraph Clients
    SA[Superadmin Console<br/>React]
    TU[Tenant App<br/>React PWA - mobile first]
  end
  CDN[CDN / WAF] --> API
  SA --> CDN
  TU --> CDN
  subgraph Platform
    API[API - NestJS<br/>REST /api/v1]
    WRK[Worker - pg-boss handlers<br/>PDF, notifications, schedulers]
    PGB[PgBouncer<br/>transaction pooling]
    DB[(PostgreSQL<br/>RLS enforced)]
    REP[(Read replica<br/>reports)]
    OBJ[(Object storage<br/>tenant-prefixed)]
  end
  API --> PGB --> DB
  WRK --> PGB
  DB --> REP
  API --> OBJ
  WRK --> OBJ
  WRK --> MAIL[Email / SMS providers]
  LIS[Analyzers / external LIS<br/>HL7 v2, FHIR - later] -.-> API
```

Runtime processes (same repository, different entrypoints): `api` (HTTP), `worker` (queue consumers + schedulers), `migrator` (one-shot, owner role).

---

## 5. Multi-Tenancy Model

### 5.1 Hierarchy

```
Platform
 └── Tenant (company / organization)          ← isolation boundary
      ├── Branch (clinic location)            ← operational scope
      │    └── Stock Location (central store, pharmacy, lab, clinic room, quarantine, waste, in-transit)
      ├── Users (scoped to one tenant; assigned to 1..n branches)
      └── All clinical, inventory, billing data (tenant_id on every row)
```

### 5.2 Five isolation layers

| # | Layer | Mechanism |
|---|---|---|
| 1 | **Identity** | JWT carries `tenant_id`, `scope` (`tenant` \| `platform`), `user_id`, `branch_ids`, `roles`, `session_id`, optional `breakglass_id`. Tenant is *never* read from body/query/path. Subdomain (`{slug}.app.example`) must match the token tenant or the request is rejected (403). Superadmin uses a separate host (`console.app.example`). |
| 2 | **Application** | `TenantContext` (AsyncLocalStorage) set by guard; all repositories obtained via `withTenant()`; lint rule forbids importing the raw pool outside the DB module; every query also filters `tenant_id` explicitly. |
| 3 | **Database** | `ENABLE` + `FORCE ROW LEVEL SECURITY` on every table with `tenant_id`; runtime role is `NOSUPERUSER NOBYPASSRLS`; composite FKs include `tenant_id`; `WITH CHECK` blocks cross-tenant writes; no `SECURITY DEFINER`. |
| 4 | **Async & storage** | Job payloads always include `tenant_id`; workers re-enter tenant context per job. Object keys `t/{tenant_id}/…`; signed URLs ≤ 60 s; cache keys prefixed with tenant. |
| 5 | **Verification** | CI: auto-generated cross-tenant negative tests per table; schema linter fails the build if a table with `tenant_id` lacks RLS/FORCE/policy/index; production `rls.canary` job (JOB-18) probes with two canary tenants hourly. |

### 5.3 Superadmin model (ADR-4)

| Capability | How it is enforced |
|---|---|
| Create tenants, tenant admins; list all tenants/users; suspend/reactivate; plans & flags | Administrative tables (`tenants`, `users`, `branches`, `subscriptions`…) have policy `tenant_id = tenant OR scope='platform'`. |
| See platform-wide metrics | Aggregate views/materialized views **without patient identifiers** (counts, usage, health). |
| Access a specific clinic's operational/PHI data | **“Enter clinic”**: superadmin selects tenant, supplies a *reason*; a `breakglass_sessions` row is created (time-boxed, default 60 min, renewable), a new JWT is minted with `scope='tenant'`, `tenant_id=<target>`, `breakglass_id`, and `acting_as_platform=true`. All actions are audited with the break-glass id; tenant admin is notified (configurable); a persistent banner shows in the UI. |
| Never possible | A single SQL statement spanning tenants' PHI tables. Cross-clinic PHI views do not exist by design. |

PHI tables therefore have only the strict policy (`tenant_id = current tenant`), while administrative tables add the platform clause.

### 5.4 Tenant resolution & login

1. `slug` → `tenant_directory(id, slug, status)` — a tiny non-PHI table with no RLS (granted narrowly), kept in sync by trigger.
2. App sets tenant context from the resolved id and authenticates the user *inside* that tenant context.
3. Suspended/offboarding tenants fail at step 1.

---

## 6. Database Architecture

### 6.1 Roles

```sql
CREATE ROLE clinic_owner  NOLOGIN;                                  -- owns objects; used by migrator only
CREATE ROLE clinic_app    LOGIN NOSUPERUSER NOBYPASSRLS;            -- api + worker
CREATE ROLE clinic_report LOGIN NOSUPERUSER NOBYPASSRLS;            -- read replica, reports
CREATE SCHEMA app AUTHORIZATION clinic_owner;                       -- helper functions
GRANT USAGE ON SCHEMA public, app TO clinic_app, clinic_report;
ALTER DEFAULT PRIVILEGES FOR ROLE clinic_owner IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO clinic_app;
-- append-only tables get explicit REVOKE UPDATE, DELETE (audit_log, stock_movements, phi_access_log)
```

### 6.2 Context helpers (SECURITY INVOKER)

```sql
CREATE FUNCTION app.tenant_id() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT NULLIF(current_setting('app.tenant_id', true), '')::uuid $$;

CREATE FUNCTION app.is_platform() RETURNS boolean LANGUAGE sql STABLE AS
$$ SELECT COALESCE(current_setting('app.scope', true), '') = 'platform' $$;

CREATE FUNCTION app.user_id() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT NULLIF(current_setting('app.user_id', true), '')::uuid $$;
```

### 6.3 Policy templates

```sql
-- (A) Tenant-owned PHI / operational table (strict)
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE patients FORCE  ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON patients
  USING      (tenant_id = (SELECT app.tenant_id()))
  WITH CHECK (tenant_id = (SELECT app.tenant_id()));

-- (B) Administrative table visible to platform scope (tenants, users, branches, subscriptions…)
CREATE POLICY tenant_or_platform ON users
  USING      (tenant_id = (SELECT app.tenant_id()) OR (SELECT app.is_platform()))
  WITH CHECK (tenant_id = (SELECT app.tenant_id()) OR (SELECT app.is_platform()));
```

`(SELECT …)` wrapping lets the planner evaluate the function once. With no tenant set, `tenant_id = NULL` matches **zero rows** (fail-closed).

### 6.4 Schema conventions

- **IDs:** UUIDv7 (time-ordered) `id`; every tenant table also has `UNIQUE (tenant_id, id)` so children can use **composite FKs**:
  `FOREIGN KEY (tenant_id, patient_id) REFERENCES patients (tenant_id, id)` — makes cross-tenant references impossible even without RLS.
- **Standard columns:** `tenant_id`, `created_at`, `created_by`, `updated_at`, `updated_by`, `row_version int` (optimistic locking); `deleted_at` on archivable master data; `branch_id` where branch-scoped.
- **Indexes:** `tenant_id` is the leading column of every hot-path index.
- **Types:** money `numeric(14,2)`, unit cost `numeric(14,4)`, quantities `numeric(14,3)` in **base UOM**; timestamps `timestamptz` (UTC) + tenant timezone (default `Asia/Manila`) for rendering/cron; dates for expiry.
- **Enums:** `text` + `CHECK` (easier migrations than PG enums) or lookup tables for tenant-configurable lists.
- **Naming:** `snake_case`, plural tables, `_id` FKs, `_at` timestamps.
- **Search:** `pg_trgm` + `unaccent` for patient/item/drug lookup; `tsvector` for notes (off by default for PHI notes).
- **Partitioning:** `audit_log`, `phi_access_log`, `stock_movements`, `notification_log` by month (range on time); hash-partition by `tenant_id` only if a table passes ~100M rows.
- **Migrations:** forward-only SQL, executed by `clinic_owner`; every migration touching a tenant table must include RLS/FORCE/policy/index (linter-enforced). Expand/contract for zero-downtime.
- **Sequences:** `number_sequences(tenant_id, branch_id, doc_type, period, last_value)` incremented with `UPDATE … RETURNING` inside the business transaction (gapless for ORs/invoices).

### 6.5 Request transaction wrapper

```ts
export async function withTenant<T>(ctx: RequestContext, fn: (tx: PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `SELECT set_config('app.tenant_id',  $1, true),   -- true = transaction-local
              set_config('app.user_id',    $2, true),
              set_config('app.scope',      $3, true),
              set_config('app.branch_id',  $4, true),
              set_config('app.request_id', $5, true)`,
      [ctx.tenantId ?? '', ctx.userId ?? '', ctx.scope, ctx.branchId ?? '', ctx.requestId]);
    const out = await fn(client);
    await client.query('COMMIT');
    return out;
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}
```

Because settings are transaction-local, PgBouncer **transaction pooling** is safe. Every request/job runs in exactly one such transaction (or explicit sub-transactions via savepoints). No session-level `SET` is permitted (lint + connection-reset on checkout as a second guard).

---

## 7. Data Model Overview

```mermaid
erDiagram
  TENANT ||--o{ BRANCH : has
  TENANT ||--o{ USER : has
  BRANCH ||--o{ STOCK_LOCATION : has
  TENANT ||--o{ PATIENT : owns
  PATIENT ||--o{ VISIT : has
  VISIT ||--o{ PRESCRIPTION : orders
  VISIT ||--o{ LAB_ORDER : orders
  PRESCRIPTION ||--o{ DISPENSE : fulfilled_by
  LAB_ORDER ||--o{ LAB_ORDER_ITEM : contains
  LAB_ORDER_ITEM ||--o{ LAB_RESULT : yields
  ITEM ||--o{ STOCK_BATCH : has
  STOCK_BATCH ||--o{ STOCK_BALANCE : held_at
  STOCK_LOCATION ||--o{ STOCK_BALANCE : holds
  STOCK_MOVEMENT }o--|| STOCK_BATCH : moves
  PURCHASE_ORDER ||--o{ GOODS_RECEIPT : received_by
  REQUISITION ||--o{ ISSUE : fulfilled_by
  DISPENSE ||--o{ STOCK_MOVEMENT : posts
  GOODS_RECEIPT ||--o{ STOCK_MOVEMENT : posts
  ISSUE ||--o{ STOCK_MOVEMENT : posts
  VISIT ||--o{ INVOICE : billed_by
```

The full table catalog (columns, constraints) is in **specification.md §4–§13**.

---

## 8. Unified Inventory Architecture

Pharmacy stock, lab reagents, and general supplies share one engine so that *central supply → pharmacy/lab → patient* is traceable by batch.

### 8.1 Concepts

| Concept | Description |
|---|---|
| `items` | One master for all stockable things; `item_type ∈ {DRUG, LAB_REAGENT, MEDICAL_SUPPLY, CONSUMABLE, OFFICE, OTHER}`; `drug_products` and `lab_tests` link to items. |
| `stock_locations` | Per branch: `CENTRAL_STORE`, `PHARMACY`, `LABORATORY`, `CLINIC_ROOM`, `QUARANTINE`, `WASTE`, `IN_TRANSIT`. |
| `stock_batches` | (item, lot no, expiry, supplier, unit cost, status `AVAILABLE/QUARANTINED/EXPIRED/RECALLED/DEPLETED`). |
| `stock_movements` | **Append-only** ledger; signed qty in base UOM; typed (`GRN`, `ISSUE_OUT`, `ISSUE_IN`, `DISPENSE`, `SALE`, `PATIENT_RETURN`, `SUPPLIER_RETURN`, `ADJ_GAIN`, `ADJ_LOSS`, `COUNT_VARIANCE`, `DISPOSAL`, `CONSUMPTION`, `TRANSFER_OUT`, `TRANSFER_IN`, `REVERSAL`) with `ref_type/ref_id`, reason, user, cost. |
| `stock_balances` | (tenant, location, batch) → `qty_on_hand`, `qty_reserved`; `CHECK (qty_on_hand >= 0 AND qty_reserved >= 0 AND qty_reserved <= qty_on_hand)`. Updated in the **same transaction** as the movement. |
| Costing | Batch-specific unit cost (specific identification); valuation = Σ balance × batch cost. |
| UOM | Base UOM per item with `uom_conversions`; documents store entered UOM + converted base qty. |

### 8.2 FEFO allocation (issue / dispense / consume)

```sql
SELECT bal.id, bal.batch_id, bal.qty_on_hand - bal.qty_reserved AS available
FROM   stock_balances bal
JOIN   stock_batches  b ON b.tenant_id = bal.tenant_id AND b.id = bal.batch_id
WHERE  bal.tenant_id = app.tenant_id()
  AND  bal.location_id = $1 AND bal.item_id = $2
  AND  bal.qty_on_hand - bal.qty_reserved > 0
  AND  b.status = 'AVAILABLE' AND b.expiry_date > CURRENT_DATE
ORDER  BY b.expiry_date ASC, b.received_at ASC, b.id
FOR UPDATE OF bal;                       -- deterministic order ⇒ no deadlocks
```

The service walks rows until the requested base quantity is satisfied, writes one movement per batch touched, updates balances, and fails the whole transaction if insufficient. Pharmacists may **override** batch choice (logged reason) — e.g., to use a specific lot; expired/quarantined/recalled batches can never be selected.

### 8.3 Consistency guarantees

- Movement + balance + source document status update commit atomically.
- Nightly `stock.balance.reconcile` (JOB-32) recomputes balances from the ledger; any mismatch raises a high-severity alert and blocks the affected item/location until resolved.
- Posted documents cannot be edited; use `REVERSAL` movements referencing the original.
- Idempotency: every posting endpoint accepts `Idempotency-Key`; unique `(tenant_id, idempotency_key)` prevents double posting on retry.

### 8.4 Replenishment

- `location_item_params(min, max, par, reorder_point, lead_time_days)` per location.
- Pull: department requisition. Push: `par.replenishment.suggest` (JOB-30) drafts requisitions when balance < par.
- Purchasing: `po.reorder.suggest` (JOB-31) proposes PRs from central-store reorder points and usage.

---

## 9. Application Architecture (Modular Monolith)

```
apps/
  api/                     # NestJS HTTP
  worker/                  # pg-boss consumers, schedulers
  web/                     # React (tenant app + platform console routes)
packages/
  db/                      # migrations, drizzle schema, withTenant, RLS linter
  contracts/               # OpenAPI + zod schemas shared FE/BE
  domain/                  # pure domain logic (FEFO, flags, delta checks)
  jobs/                    # job definitions (name, schedule, handler, retry policy)
  ui/                      # shared React components (design system)
modules/ (inside api)
  platform  tenancy  iam  patients  clinical  lab  pharmacy  supply  billing
  compliance  notifications  reports  files  integrations
```

Rules: modules talk via **application services or domain events** (outbox), not each other's tables. `lab`/`pharmacy` call `supply.InventoryService` for all stock effects. Cross-module reads go through query services.

---

## 10. Authentication & Authorization

| Topic | Design |
|---|---|
| Passwords | Argon2id; breached-password check; min length 12; lockout with backoff; forced reset on admin-set password |
| MFA | TOTP mandatory for platform users, tenant admins, pharmacists (controlled drugs), lab verifiers; optional for others (tenant policy) |
| Tokens | 10-min access JWT; refresh in httpOnly, `SameSite=Strict`, `Secure` cookie, rotated with reuse detection; `session_id` revocable |
| RBAC | `permissions` (global catalog) → `roles` (per tenant, seeded from system templates) → `user_roles` (per branch or tenant-wide) |
| ABAC layers | (a) branch scope; (b) `patients.restricted` (VIP/staff records: explicit grant + reason); (c) `lab_tests.is_confidential` (e.g., HIV-related) requires `lab.result.view_confidential`; (d) controlled-drug actions require `pharmacy.controlled.*` + MFA step-up |
| Segregation of duties | Configurable: result entry ≠ verification; PO creator ≠ approver; adjustment requester ≠ approver; dispensing controlled drug needs witness |
| Step-up | Re-auth (password/TOTP) for void/refund, adjustment approval, controlled dispense, break-glass |
| Service accounts | Tenant API keys (hashed, scoped, rotatable) for instrument/LIS integrations; bound to one tenant |

Authorization is enforced in NestJS guards (`@RequirePermission('lab.result.verify')`) **and** re-checked in domain services for state transitions.

---

## 11. API Design

- REST JSON under `/api/v1`; OpenAPI generated; shared zod contracts.
- Resources are tenant-implicit (no tenant id in paths). Platform endpoints live under `/api/v1/platform/*` and require `scope=platform`.
- Collections: `GET /resources?filter[...]&sort=&page[size]=&page[cursor]=`; cursor pagination for ledgers/logs, offset allowed for small masters.
- Writes: `POST` create, `PATCH` partial update with `If-Match: <row_version>` (412 on conflict), `DELETE` = archive (soft) where allowed.
- Transitions: `POST /purchase-orders/{id}/approve`, `/lab-orders/{id}/verify`, `/dispenses/{id}/post` etc. Transitions are explicit verbs, validated against the state machine.
- Idempotency: `Idempotency-Key` header required on all posting/transition endpoints.
- Errors: RFC 9457 problem+json with stable `code` (e.g., `STOCK_INSUFFICIENT`, `BATCH_EXPIRED`, `TENANT_MISMATCH`).
- Rate limiting per user and per tenant; stricter on auth endpoints.
- Async operations (exports, big reports): `202 Accepted` + `/jobs/{id}` polling + notification.

---

## 12. Background Jobs Architecture

| Aspect | Design |
|---|---|
| Engine | pg-boss in the same Postgres (separate schema `pgboss`); multiple worker replicas (SKIP LOCKED ⇒ no double processing) |
| Types | **Scheduled (cron)**, **event-driven** (enqueued from outbox/domain events), **delayed** (`startAfter`), **singleton** (dedupe key) |
| Tenant fan-out | A scheduled *coordinator* job enumerates active tenants (platform scope, ids only) and enqueues one **tenant-scoped child job per tenant**; child handler calls `withTenant(tenant)` so RLS applies. Cron is evaluated per tenant timezone. |
| Payload contract | `{ tenantId, branchId?, idempotencyKey, params }` — validated by zod; missing tenant = rejected |
| Reliability | Retries with exponential backoff; per-job timeout; dead-letter queue; idempotent handlers; `job_runs` view for the platform console |
| Isolation | Per-tenant concurrency caps (singleton keys) to prevent noisy neighbors; heavy report/PDF jobs on a separate queue with lower priority |
| Observability | Metrics per job (duration, failures, lag) with `tenant_id` label; alert on dead-letter growth and schedule misses |
| Catalog | 50 jobs defined in **specification §5** (IDs `JOB-01…JOB-50`) |

**Transactional outbox:** domain events are inserted into `outbox` in the same transaction as the state change; `outbox.dispatch` (JOB-01) publishes to queues/notifications. No dual-write.

---

## 13. Notifications

Channels: in-app (bell), email, SMS, web push. Templates per tenant (language `en`/`fil`). Delivered via outbox → `notification.send` (JOB-02) with provider abstraction, retries, delivery log, per-user preferences, and quiet hours (except critical lab values and stock-out of controlled drugs).

---

## 14. Files & Documents

- Uploads (patient documents, lab attachments, signatures, logos, supplier docs) → object storage at `t/{tenant_id}/{domain}/{uuid}`; metadata in `files` table with RLS; SSE enabled.
- Size/type allow-list; antivirus scan job before availability; pre-signed GET ≤ 60 s; downloads logged to `phi_access_log` when patient-linked.
- Generated PDFs (lab reports, prescriptions, certificates, receipts, reports) stored immutably with SHA-256; re-render creates a new version, old retained.

---

## 15. Audit & Compliance Architecture

| Control | Implementation |
|---|---|
| **Audit trail** | `audit_log` (insert-only, monthly partitions): actor, tenant, `acting_as_platform`, `breakglass_id`, action, entity, before/after JSON (PHI fields masked where not needed), request id, IP, UA, per-tenant **hash chain** (`prev_hash`, `row_hash`) verified daily (JOB-10). |
| **PHI access log** | Every read of a patient record, result, or document writes `phi_access_log` (who, patient, resource, purpose, time). Viewable by DPO/auditor and per patient. |
| **Consent** | Versioned consent templates; signed/recorded consent per patient with purposes; withdrawal tracked. |
| **Data subject rights** | `data_subject_requests` workflow with SLA reminders (JOB-16); erasure = anonymization subject to legal retention/hold. |
| **Breach management** | Incident register with timers to notify the regulator/data subjects within the prescribed period (JOB-17; period configurable, confirm with DPO). |
| **Retention** | `retention_policies` per record class; `retention.enforce` (JOB-15) flags/anonymizes; legal holds override. Defaults set conservatively and confirmed with counsel. |
| **Processor obligations** | Platform acts as Processor: DPA/outsourcing contract template, sub-processor list, audit rights, breach notice to tenant. |
| **Encryption** | TLS 1.2+ everywhere; encrypted volumes & backups; envelope encryption (per-tenant DEK via KMS) for especially sensitive columns (government IDs, confidential results). |
| **Access reviews** | Quarterly user-access recertification report (RPT-CMP-06). |

Tenants are responsible as Controllers for appointing a DPO, privacy impact assessments, and (where thresholds are met, e.g., large-scale sensitive data) registration with the National Privacy Commission — the platform supplies a compliance checklist and evidence reports.

---

## 16. Security Controls (summary)

OWASP ASVS L2 as baseline · CSP strict, no inline scripts · CSRF protection for cookie flows · input validation with zod on every endpoint · parameterized SQL only · SSRF-safe outbound calls · secrets in a vault, rotated · dependency & container scanning in CI · SAST + secret scanning · WAF & DDoS protection · least-privilege DB/network policies · no PHI in logs/metrics/traces (structured-log redaction) · annual penetration test · tenant-isolation pen-test scenarios (IDOR, JWT swap, header spoof, queue poisoning, report/export scoping).

---

## 17. Observability & Operations

- Structured JSON logs with `request_id`, `tenant_id`, `user_id` (hashed in logs), route, duration; PHI redaction middleware.
- Metrics: RED per route, DB pool saturation, slow queries per tenant, job lag, stock reconcile mismatches, RLS canary status.
- Tracing: OpenTelemetry through API → DB → worker.
- Per-tenant usage metering (rows, storage, API calls) for plans and noisy-neighbor detection (alert on per-tenant row-growth anomalies).
- SLOs: API availability 99.9 %, p95 latency < 300 ms for CRUD / < 1 s for searches, job schedule adherence 99 %.

---

## 18. Deployment, Backup & DR

| Topic | Design |
|---|---|
| Environments | `dev` (docker-compose + MinIO + Mailpit), `test` (ephemeral per PR), `staging` (prod-like, synthetic data only), `prod` |
| Hosting | Containers on Kubernetes/managed platform; managed Postgres with HA; PgBouncer; region chosen with data-residency counsel (PH or nearby APAC region) |
| Releases | Blue/green or rolling; migrations as pre-deploy job (expand/contract); feature flags per tenant |
| Backups | Continuous WAL archiving (PITR), daily base backups, encrypted, cross-region copy; **RPO ≤ 5 min, RTO ≤ 1 h**; weekly automated restore test (JOB-14) |
| Tenant export | `tenant.export` (JOB-04) produces an encrypted archive through RLS-scoped queries only |
| Offboarding | Export → retention hold → `tenant.offboard.purge` (JOB-05) hard-deletes tenant rows and objects; backups age out per policy |
| Scaling path | Vertical → read replica for reports → partition hot tables → **promote heavy tenant to dedicated DB** using `tenant_directory.db_shard` routing |

---

## 19. Testing Strategy

| Level | Tooling | Must-haves |
|---|---|---|
| Unit | Vitest | FEFO, unit conversions, reference-range flags, delta checks, state machines |
| DB/integration | Testcontainers Postgres | Migrations, RLS policies, constraints, concurrency (parallel dispenses never oversell) |
| **Tenant isolation (release gate)** | Generated suite | For every tenant table & endpoint: seed tenants A/B, authenticate as A, assert zero B rows / 404 on B ids, cross-tenant FK rejected, `WITH CHECK` blocks forged `tenant_id`, job payload tampering rejected |
| API contract | OpenAPI + Schemathesis/Dredd | No breaking changes |
| E2E | Playwright (mobile + desktop viewports) | Registration → consult → lab → Rx → dispense → bill; PO → GRN → requisition → issue |
| Security | ZAP, dependency scan, pen-test | Auth, IDOR, break-glass |
| Accessibility | axe + manual | WCAG 2.1 AA |
| Performance | k6 | 200 concurrent users per tenant, noisy-neighbor scenario |
| Chaos/DR | Scheduled | Restore drill, worker kill mid-job (idempotency) |

---

## 20. Interoperability Roadmap

1. **v1:** PDF reports, CSV/XLSX exports, barcode labels, printable prescriptions/certificates.
2. **v1.5:** Lab instrument interface via HL7 v2 / ASTM (ORM/OML orders, ORU results, accession-number matching, corrected-result `OBX-11 = C`), LOINC mapping table per tenant.
3. **v2:** FHIR R4 (`Patient`, `Encounter`, `Observation`, `DiagnosticReport`, `MedicationDispense`), and integration with the national health information exchange as it becomes applicable (de-identified data only).

---

## 21. Assumptions, Risks & References

**Assumptions:** PH is the primary market (PHP, `Asia/Manila`, PSGC addresses, RA 10173 / RA 9165 / RA 10918 context); 100–300 tenants in the first 18 months; most tenants 1–5 branches; clinics (not hospitals).

| Risk | Mitigation |
|---|---|
| RLS misconfiguration leaks data | Linter + generated negative tests + canary job + FORCE RLS + non-bypass role |
| Connection-pool context bleed | Transaction-local settings only; no session `SET`; reset on checkout |
| Stock drift | Ledger + nightly reconcile + `CHECK` constraints + immutable postings |
| Regulatory interpretation | Config-driven rules; counsel/DPO review before go-live |
| Superadmin over-reach | Break-glass with reason, time-box, tenant notification, audit |
| Noisy neighbor | Per-tenant rate limits, job concurrency caps, metering |

**References (research)**

- PostgreSQL RLS for multi-tenant SaaS — https://clickhouse.com/resources/engineering/multi-tenant-saas-postgres-architecture · https://postgresql.codeguides.io/multi-tenant-patterns/best-practices/ · https://theroadtoenterprise.com/blog/postgres-rls-multi-tenant-saas · https://ricofritzsche.me/mastering-postgresql-row-level-security-rls-for-rock-solid-multi-tenancy/
- Philippine Data Privacy Act (RA 10173) — https://privacy.gov.ph/data-privacy-act/ · https://www.respicio.ph/commentaries/patient-privacy-and-confidentiality-laws-in-the-philippines
- Dangerous drugs handling (DDB/PDEA) — https://ddb.gov.ph/images/Board_Regulation/2014/BD.REG1.14.pdf · https://www.pna.gov.ph/articles/1097377
- Pharmacy FEFO & expiry management — https://www.pharmacytimes.com/view/the-art-of-inventory-management-how-techs-keep-pharmacies-running-smoothly · https://cpcongroup.com/insights/article/pharmacy-inventory-management/
- Laboratory information systems, HL7/LOINC — https://acquaintsoft.com/blog/laboratory-information-system-development · https://mirth.support/blog/hl7-orm-oru-lab-workflow
- Central supply / par-level replenishment — https://casrai.org/dictionary/term/central-stores · https://www.rfsmart.com/blog/hospital-materials-management-replenishment-best-practices
- pg-boss — https://github.com/timgit/pg-boss · https://www.pkgpulse.com/guides/bullmq-vs-bee-queue-vs-pg-boss-job-queues-nodejs-2026

> This document is an engineering design, not legal advice. Regulatory behaviors must be validated with qualified counsel and each tenant's Data Protection Officer.
