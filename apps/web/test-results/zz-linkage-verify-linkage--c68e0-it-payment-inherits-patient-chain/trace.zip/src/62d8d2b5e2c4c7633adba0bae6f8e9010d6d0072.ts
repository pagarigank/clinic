// THROWAWAY verification spec for invoice -> patient -> visit -> payment linkage.
// The main clinical chain is blocked at step 3 by the seeding defect, so this
// exercises the billing leg on its own against an existing E2E patient.
import { test, expect } from "@playwright/test";
import { login } from "./auth.js";

const PATIENT_NO = process.env.LINKAGE_PATIENT_NO ?? "PAT-2026-0020";

test.use({ storageState: { cookies: [], origins: [] } });

test.describe("linkage", () => {
  test("invoice carries patient and visit; payment inherits patient", async ({ page }) => {
    await login(page, "admin");
    await page.goto("/billing/invoices");
    await page.getByRole("button", { name: /New Invoice/i }).click();
    const modal = page.locator(".modal", { hasText: "Create New Invoice" });
    await expect(modal).toBeVisible();

    await modal.getByLabel("Search patient").fill(PATIENT_NO);
    const match = modal.locator(".list-group-item").first();
    await expect(match).toBeVisible({ timeout: 15_000 });
    await match.click();

    const visitSelect = modal.getByLabel("Select visit");
    await expect(visitSelect).toBeVisible({ timeout: 15_000 });
    const option = visitSelect.locator("option:not([value=''])").first();
    // <option> is never "visible" inside a closed <select>; assert presence.
    await expect(option).toHaveCount(1, { timeout: 15_000 });
    const visitValue = await option.getAttribute("value");
    expect(visitValue, "patient has no visit to invoice against").toBeTruthy();
    await visitSelect.selectOption(visitValue!);

    const resp = page.waitForResponse(
      (r) => r.url().includes("/billing/invoices") && r.request().method() === "POST",
    );
    await modal.getByRole("button", { name: /Create Invoice/i }).click();
    const body: any = await (await resp).json();
    console.log("CREATE INVOICE RESPONSE:", JSON.stringify(body?.invoice ?? body));

    expect(body?.invoice?.patientId ?? body?.patientId, "invoice patientId not returned").toBeTruthy();
    expect(body?.invoice?.visitId ?? body?.visitId, "invoice visitId not returned").toBeTruthy();
  });
});